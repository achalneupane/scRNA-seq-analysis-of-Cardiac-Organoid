#
#   Copyright (c) 2023 Parse Biosciences
#
#   See company page for background information, usage instructions and license.
#   https://www.parsebiosciences.com/
#

from setuptools import setup

# From https://stackoverflow.com/questions/40031422/python-recursively-include-package-data-in-setup-py
from pathlib import Path

datadir = Path(__file__).parent / 'splitpipe'
files = [str(p.relative_to(datadir)) for p in datadir.rglob('*')]

setup(
    name='splitpipe',
    version='1.0.6+p',

    # Generic url, description
    url='https://www.parsebiosciences.com/',
    description="Parse Bioscience's data analysis pipeline",

    # Package and top-level script
    packages=['splitpipe'],
    scripts=['split-pipe'],

    # Requirements
    python_requires='>=3.7',

    install_requires=[
        'numpy',
        'pandas',
        'scipy',
        'matplotlib',
        'h5py',
        'pysam',
        'scanpy',
        'anndata',
        'louvain',
        'leidenalg',
        'python-igraph',
        'jinja2',
        'psutil',
        'openpyxl==3.0.9'       # Newer version not working for SampleLoadingTable
    ],

    # Data for package
    package_data={'splitpipe': files},
    #package_data={
    #    'splitpipe': ['config/*', 'barcodes/*', 'templates/*', 'scripts/*', 'TCR/*'],
    #},
    include_package_data=True,

)
