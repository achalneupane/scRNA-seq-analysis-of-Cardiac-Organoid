#
#   Copyright (c) 2023 Parse Biosciences
#
#   See company page for background information, usage instructions and license.
#   https://www.parsebiosciences.com/
#
# Barcode funcitons

import re
import os
import json
import numpy as np
import pandas as pd
from collections import defaultdict


LOCAL_IMPORT=0

if LOCAL_IMPORT:
    import bcutils
    import plates
    import utils
else:
    from splitpipe import bcutils
    from splitpipe import plates
    from splitpipe import utils


DNA_BASES = set(list('ACGT'))


### ------------------------------ Barcode setup --------------------------------

def get_bc_info(bc_rounds, path, amp_seq, verb=False):
    """ Set up barcode related structures

    Load seqs (pandas series) and similar-edit-dics
    Create seq >--> index dicts

    bc_rounds = list as: [['bc1','n192_v4'], ['bc2','v1'], ['bc3','v1']]

    Return bc_info, story
    """
    #print("bc_rounds", bc_rounds)
    #print("gbi path", path)

    bc_info = {}
    story = ''

    # Amplicon info; Seq and start,end for each round (zero = polyN)
    bc_info['amp_seq'] = amp_seq
    bc_starts, bc_ends = get_amp_part_bounds(amp_seq)
    bc_info['bc_starts'] = bc_starts
    bc_info['bc_ends'] = bc_ends

    # Init lists with nothing (i.e. no round 0, rounds 1-3 have stuff)
    bc_round_name = [None]
    bc_dfs = [None]
    bc_seqs = [None]
    bc_dicts = [None]
    bc_seq_to_bci = [None]
    bc_seq_to_type = [None]
    bc_seq_to_wind = [None]
    bc_seq_to_wind_str = [None]
    bc_wind_to_str = [None]
    bc_bci_to_wind = [None]
    bc_bci_to_well = [None]
    bc_bci_to_type = [None]
    bc_bci_to_seq = [None]

    # Load barcode seqs and within-edit-distance dicts
    # Filename templates
    BC_DF_TEMP = "{path}/barcodes/bc_data_{bc_ver}.csv"
    BC_DIC_TEMP = "{path}/barcodes/bc_dict_{bc_ver}.json"
    bc_round = 1
    for rlist in bc_rounds:
        bc_ver = rlist[1]
        #print("rlist, bc_ver", rlist, bc_ver)
        df_fname = BC_DF_TEMP.format(path=path, bc_ver=bc_ver)
        dict_fname = BC_DIC_TEMP.format(path=path, bc_ver=bc_ver)
        bc_dict = map_dict = None

        #print("files", df_fname, dict_fname)
        bc_df = bc_dict = map_dict = None

        try:
            bc_df = read_bc_data_csv(df_fname, verb=verb)
            bc_dict = read_bc_dict(dict_fname, verb=verb)
            map_dict = get_bc_data_dicts(bc_df)
        except:
            bc_dict = map_dict = None

        if not map_dict:
            story = f"Barcode {rlist} failed; file(s) {df_fname} {dict_fname}"
            return None, story

        bc_round_name.append(bc_ver)
        # Edit dists dicts
        bc_dicts.append(bc_dict)
        # Save dataframe as is, but also sequences as list
        bc_df['bc_round'] = bc_round
        bc_dfs.append(bc_df)
        bc_seqs.append(list(bc_df['sequence'].values))
        # Mapping dicts
        bc_seq_to_bci.append(map_dict['bc_seq_to_bci'])
        bc_seq_to_type.append(map_dict['bc_seq_to_type'])
        bc_seq_to_wind.append(map_dict['bc_seq_to_wind'])
        bc_seq_to_wind_str.append(map_dict['bc_seq_to_wind_str'])
        bc_wind_to_str.append(map_dict['bc_wind_to_str'])
        bc_bci_to_well.append(map_dict['bc_bci_to_well'])
        bc_bci_to_wind.append(map_dict['bc_bci_to_wind'])
        bc_bci_to_type.append(map_dict['bc_bci_to_type'])
        bc_bci_to_seq.append(map_dict['bc_bci_to_seq'])

        bc_round += 1

    # Pack everything
    bc_info['bc_round_name'] = bc_round_name
    bc_info['bc_dicts'] = bc_dicts
    bc_info['bc_data'] = bc_dfs
    bc_info['bc_seqs'] = bc_seqs
    bc_info['bc_seq_to_bci'] = bc_seq_to_bci
    bc_info['bc_seq_to_type'] = bc_seq_to_type
    bc_info['bc_seq_to_wind'] = bc_seq_to_wind
    bc_info['bc_seq_to_wind_str'] = bc_seq_to_wind_str
    bc_info['bc_wind_to_str'] = bc_wind_to_str
    bc_info['bc_bci_to_well'] = bc_bci_to_well
    bc_info['bc_bci_to_wind'] = bc_bci_to_wind
    bc_info['bc_bci_to_type'] = bc_bci_to_type
    bc_info['bc_bci_to_seq'] = bc_bci_to_seq

    return bc_info, story


# For parsing amplicon representation into BC and polyN start positions
def bc_amp_part_index(b):
    """ Part index for given character

    If normal DNA base, -1
    If 'N' then = 0 for polyN
    If int, then int N for barcode-N
    """
    if b in DNA_BASES:
        index = -1
    else:
        if b == 'N':
            index = 0
        else:
            index = int(b)
    return index


def get_amp_part_bounds(seq):
    """ Get start and end coords (for slice) for non-base parts in seq

    Assumes amplicon like below, with BC as digit, (optional) polyN as N
    bc_amp_seq = 'NNNNNNNNNN33333333GTGGCCGATGTTTCGCATCGGCGTACGACT22222222ATCCACGTGCTTGAGACTGTGG11111111'

    Result lists are indexed [0]=N; [1]=round1; [2]=round2; [3]=round3

    Return arrays of start and end coords (for string slicing)
    """
    non_dna = set(seq.upper()) - DNA_BASES
    num_parts = len(non_dna)
    # If no N given, bump size
    if 'N' not in non_dna:
        num_parts += 1
    part_ends = [-1] * num_parts
    part_starts = [-1] * num_parts
    # Scan each char; Annotate non-base parts
    prev_pi = -1
    i = 0
    while i < len(seq):
        pi = bc_amp_part_index(seq[i])
        # Change of part
        if pi != prev_pi:
            if pi >= 0:
                part_starts[pi] = i
            if prev_pi >= 0:
                part_ends[prev_pi] = i
        prev_pi = pi
        i += 1

    # Last end coord
    if part_ends[prev_pi] < 0:
        part_ends[prev_pi] = i
    return part_starts, part_ends


def rev_comp_amp_part_bounds(seq, starts, ends):
    """ Change start and end positions for rev comp sequence case

    Return tuple (starts, ends)
    """
    new_starts = []
    new_ends = []
    for s, e in zip(starts, ends):
        if s < 0:
            new_starts.append(-1)
            new_ends.append(-1)
        else:
            new_starts.append(len(seq)-e)
            new_ends.append(len(seq)-s)
    return new_starts, new_ends


def barcode_path():
    """ Get path for installed barcodes
    """
    path = os.path.dirname(__file__) + '/barcodes/'
    return path


BC_DATA_NAME_REGEX = re.compile(r'.*/?bc_data_(\w+).csv')
BC_DICT_NAME_REGEX = re.compile(r'.*/?bc_dict_(\w+).json')
BC_JSTR_NAME_REGEX = re.compile(r'.*/?bc_data_(\w+).jstring')

def barcode_filepaths(bc_path=None, jstring=False):
    """ Get filenames for barcodes

    jstring = Flag to get (combined data and dict) encoded jstring files

    If jstring, return dict[bc] = file
    else dict[bc] = {'data_file': file, 'dict_file': file}

    Return dict with [name] = dict of file paths
    """
    if not bc_path:
        bc_path = barcode_path()

    new_dict = {}
    # Legit barcode sets are either jstring or have both csv data and json dict files
    if jstring:
        jstr_files = utils.fnames_for_path(bc_path, ext='jstring', depth=0)
        new_dict = utils.fname_list_to_dict(jstr_files, regex=BC_JSTR_NAME_REGEX, regex_key=1)
    else:
        csv_files = utils.fnames_for_path(bc_path, ext='csv', depth=0)
        json_files = utils.fnames_for_path(bc_path, ext='json', depth=0)
        csv_dict = utils.fname_list_to_dict(csv_files, regex=BC_DATA_NAME_REGEX, regex_key=1)
        json_dict = utils.fname_list_to_dict(json_files, regex=BC_DICT_NAME_REGEX, regex_key=1)
        # Return dict has names for both files
        for name in sorted(csv_dict.keys()):
            if name in json_dict:
                new_dict[name] = {'data_file': csv_dict[name], 'dict_file': json_dict[name]}
    return new_dict


def bc_list_to_dict(bc_rounds, verb=True):
    """ Parse bc_round_set list to dict[round] = name

    bc_rounds = list as: [['bc1','n192_v4'], ['bc2','v1'], ['bc3','v1']]

    Return dict; int keys [1] = name, [2] = name
    """
    new_dict = {}
    for i, bc_tup in enumerate(bc_rounds):
        # Sublists may actually have extra stuff... just get first two
        bc, name = bc_tup[:2]
        # Get int from bc; May be int or string like 'bc1'
        ok, n = utils.str_to_num(bc, regex=True)
        if not ok:
            if verb:
                print(f"Problem int from barcode spec[{i}] {bc_tup}")
                print(bc_rounds)
            return None
        new_dict[n] = name
    return new_dict


def well_to_wind_dicts():
    """ Get dicts mapping between well string <--> 1-based int
    Assumes 96-well plate

    Return two dicts
    """
    well_to_wind = {}
    wind_to_well = {}
    n = 1
    for row in 'ABCDEFGH':
        for c in range(12):
            col = f"{c+1}"
            well = row+col
            well_to_wind[well] = n
            wind_to_well[n] = well
            n += 1
    return well_to_wind, wind_to_well


# Create once as globals
# Mappings between well str (e.g. 'A4') and index (1-based int)
WELL_TO_WIND_DICT, WIND_TO_WELL_DICT = well_to_wind_dicts()


def read_bc_data_csv(fname, verb=False):
    """ Load barcode dataframe, check / update cols

    Return dataframe
    """
    # Don't want any index; Will set after checking all cols
    df = utils.read_csv(fname, index_col=None)
    if verb:
        print(f"Loaded {fname}")

    cols = set('bci,sequence,uid,well,type'.split(','))
    if not set(cols).issubset(df.columns):
        print(f"Barcode data file problem {fname}")
        print(f"Expected cols {sorted(cols)}")
        print(f"Loaded cols   {sorted(df.columns)}")
        return None

    df.set_index('bci', inplace=True)
    df.index.name = 'bci'
    # Well lable to 1-base int index (i.e. 'B3' >--> 15)
    well_to_wind, wind_to_well = well_to_wind_dicts()
    df['well_int'] = df['well'].map(well_to_wind)

    return df


def read_bc_dict(fname, verb=False):
    """ Load barcode edit dict

    Return dict
    """
    with open(fname, 'r') as INFILE:
        bc_dict = json.load(INFILE)
        if not bc_dict:
            print(f"Failed json.load for {fname}")
            return None
        if verb:
            print(f"Loaded {fname}")

    # Top level has int keys and holds default dicts
    new_dict = {}
    for k, v in bc_dict.items():
        new_dict[int(k)] = defaultdict(list, bc_dict[k])
    return new_dict


def get_bc_well_list(df, as_str=False):
    """ Get list of (single) well strings (e.g. A4,D10) from bc dataframe

    as_str = flag to return single string (e.g. comma,sep,list)

    Return list or str
    """
    # First sorted ints then strings
    winds = get_bc_wind_list(df, as_int=True)
    wells = plates.well_index_to_str(winds)
    # If not single string, split on comma
    if not as_str:
        wells = wells.split(',')
    return wells


def get_bc_wind_list(df, bc_round=1, as_int=False):
    """ Get list of well indexes from bc dataframe

    as_int = flag to return ints; else strings

    Return list 
    """
    nlist = sorted(df['well_int'].unique())
    if as_int:
        nlist = [int(n) for n in nlist]
    else:
        nlist = [f"{n:02d}" for n in nlist]
    return nlist


def get_bc_bci_list(df, as_int=False):
    """ Get list of barcode indexes from bc dataframe

    as_int = flag to return ints; else strings

    Return list
    """
    nlist = sorted(df.index.values)
    if as_int:
        nlist = [int(n) for n in nlist]
    else:
        nlist = [str(n) for n in nlist]
    return nlist


def get_bc_num_wells(df):
    """ Get number of wells for bc dataframe

    Return int
    """
    return len(get_bc_wind_list(df))


def get_bc_plate_wells(df, as_list=False, as_int=False):
    """ Get row X col plate wells; Counts or lists

    as_list = Flag to return lists of rows, cols rather than just dims

    Return rows,cols as int,int or list,list
    """
    well_list = list(df['well'].values)
    rows = set()
    cols = set()
    for well in well_list:
        letter, number = well[0], well[1:]
        rows.add(letter)
        cols.add(number)
    # Returning just counts
    if not as_list:
        rows = len(rows)
        cols = len(cols)
    else:
        rows = sorted(rows)
        # Sort numerically, then convert back to str
        cols = sorted([int(i) for i in cols])
        if not as_int:
            cols = [str(i) for i in cols]
    return rows, cols


def get_bc_df_story(df):
    """ Get story for given barcode dataframe

    Return string
    """
    # bci may be a column or index
    if 'bci' in df.columns:
        nbc = len(df['bci'].unique())
    else:
        nbc = len(df)
    nwell = len(df['well'].unique())
    rows, cols = get_bc_plate_wells(df, as_list=True)
    # Format like "96 barcodes, 48 wells; A-D, 1-12
    return f"{nbc:3d} barcodes, {nwell:3d} wells; {rows[0]}-{rows[-1]}, {cols[0]}-{cols[-1]}"


def get_bc_data_dicts(df):
    """ Get field-to-field mapping dicts for bc dataframes

    Return dict of dicts
    """
    # Sequence keys
    bc_seq_to_bci = dict(zip(df['sequence'].values, df.index.values))
    bc_seq_to_wind = dict(zip(df['sequence'].values, df['well_int'].values))
    bc_seq_to_well = dict(zip(df['sequence'].values, df['well'].values))
    bc_seq_to_type = dict(zip(df['sequence'].values, df['type'].values))
    # String formatted well indexes
    bc_wind_to_str = get_bc_wind_str_dict(list(df['well_int'].values))
    bc_seq_to_wind_str = {k:bc_wind_to_str[v] for k,v in bc_seq_to_wind.items()}
    # bci keys
    bc_bci_to_wind = dict(zip(df.index.values, df['well_int'].values))
    bc_bci_to_well = dict(zip(df.index.values, df['well'].values))
    bc_bci_to_type = dict(zip(df.index.values, df['type'].values))
    bc_bci_to_seq = dict(zip(df.index.values, df['sequence'].values))

    new_dict = {
        'bc_seq_to_bci': bc_seq_to_bci,
        'bc_seq_to_well': bc_seq_to_well,
        'bc_seq_to_type': bc_seq_to_type,
        'bc_seq_to_wind': bc_seq_to_wind,
        'bc_seq_to_wind_str': bc_seq_to_wind_str,
        'bc_wind_to_str': bc_wind_to_str,
        'bc_bci_to_wind': bc_bci_to_wind,
        'bc_bci_to_well': bc_bci_to_well,
        'bc_bci_to_type': bc_bci_to_type,
        'bc_bci_to_seq': bc_bci_to_seq,
    }
    return new_dict


def get_bc_wind_str_dict(bc_winds, pad=True, pad_to=0):
    """ Get dict mapping well index (int) to str

    Return dict
    """
    assert isinstance(bc_winds, list), f"Expected list got {type(bc_winds)}"

    # Format string; Padded has leading zeros
    if pad_to:
        fmt = "{v:0" + str(pad_to) + "d}"
    elif pad:
        fmt = "{v:0" + str(len(str(max(bc_winds)))) + "d}"
    else:
        fmt = "{v}"
    new_dict = {k:fmt.format(v=k) for k in bc_winds}
    return new_dict


### ------------------------------ Barcode correction --------------------------------

def get_perfect_bc_counts(fq_df, bc_info, drop_valid_cols=True):
    """ Evaluate sampled barcode sequences for perfect barcode counts

    fq_df = dataframe with barcode seqs

    Return tuple (dict-with-count[perfect-bc-combo], threshold value, stats dict)
    """
    assert isinstance(fq_df, pd.DataFrame), f"Expected DataFrame got {type(fq_df)}"

    # Make sure barcode subseqs are split out
    fq_df = fq2_df_split_bc(fq_df, bc_info['amp_seq'])

    # Sets a bit faster for membership checking
    bc1_seq_set = set(bc_info['bc_seqs'][1])
    bc2_seq_set = set(bc_info['bc_seqs'][2])
    bc3_seq_set = set(bc_info['bc_seqs'][3])
    # Boolean perfect match of subseq to seq sets
    fq_df['bc1_valid'] = fq_df['bc1'].apply(lambda s: s in bc1_seq_set)
    fq_df['bc2_valid'] = fq_df['bc2'].apply(lambda s: s in bc2_seq_set)
    fq_df['bc3_valid'] = fq_df['bc3'].apply(lambda s: s in bc3_seq_set)

    # Counts of (perfect) barcode combinations
    counts = fq_df.query('bc1_valid & bc2_valid & bc3_valid')\
                  .groupby(['bc1','bc2','bc3']).size().sort_values(ascending=False)

    reads_in_cells_thresh = bc_info['pec_cell_thresh']
    calc = counts.iloc[abs(counts.cumsum() / counts.sum() - reads_in_cells_thresh).values.argmin()]
    count_threshold = max(5, calc)

    # Stats for perfect sequences
    stat_dict = {
        'bc1_perfrac': round(fq_df['bc1_valid'].sum() / len(fq_df), 3),
        'bc2_perfrac': round(fq_df['bc2_valid'].sum() / len(fq_df), 3),
        'bc3_perfrac': round(fq_df['bc3_valid'].sum() / len(fq_df), 3),
        }

    # Clean up dataframe?
    if drop_valid_cols:
        drop_cols = "bc1_valid,bc2_valid,bc3_valid".split(',')
        fq_df.drop(drop_cols, axis=1, inplace=True)

    return counts.to_dict(), count_threshold, stat_dict


def correct_barcodes(bc1, bc2, bc3, counts, count_thresh, bc_dicts, max_d):
    """ Correct barcode sequences using pre-calculated values

    Return barcodes, edit distance max, edit distance sum
    """
    bc1_matches, edit_dist1, found1 = get_min_edit_dists(bc1, bc_dicts[1], max_d)
    bc2_matches, edit_dist2, found2 = get_min_edit_dists(bc2, bc_dicts[2], max_d)
    bc3_matches, edit_dist3, found3 = get_min_edit_dists(bc3, bc_dicts[3], max_d)
    # Valid if all found
    if found1 and found2 and found3:
        ed_max = max(edit_dist1, edit_dist2, edit_dist3)
        ed_sum = edit_dist1 + edit_dist2 + edit_dist3
    else:
        return '', '', '', -1, -1

    bc1_fixed = bc2_fixed = bc3_fixed = ''
    # Perfect match == done
    if 0==edit_dist1==edit_dist2==edit_dist3:
        bc1_fixed = bc1_matches[0]
        bc2_fixed = bc2_matches[0]
        bc3_fixed = bc3_matches[0]
    # Look for single over-threshold combination
    else:
        matches = 0
        for bc1_m in bc1_matches:
            for bc2_m in bc2_matches:
                for bc3_m in bc3_matches:
                    try:
                        cur_counts = counts[(bc1_m, bc2_m, bc3_m)]
                    except:
                        cur_counts = 0
                    if cur_counts > count_thresh:
                        bc1_fixed = bc1_m
                        bc2_fixed = bc2_m
                        bc3_fixed = bc3_m
                        matches += 1
                        # More than one possibility == don't use
                        if matches > 1:
                            bc1_fixed = bc2_fixed = bc3_fixed = ''
                            break

    return bc1_fixed, bc2_fixed, bc3_fixed, ed_max, ed_sum


def get_min_edit_dists(bc, edit_dict, max_d):
    """Returns a list of nearest edit dist seqs
    Input 8nt barcode, edit_dist_dictionary
    Output <list of nearest edit distance seqs>, <edit dist>
    """
    bc_matches = edit_dict[0].get(bc, [])
    edit_dist = 0
    found = bool(bc_matches)
    while (not found) and (edit_dist < max_d):
        edit_dist += 1
        bc_matches = edit_dict[edit_dist].get(bc, [])
        if bc_matches:
            found = True
            break
        if edit_dist >= max_d:
            break
    return bc_matches, edit_dist, found


def fq2_df_split_bc(df, amp_seq, fresh=False):
    """ Add split barcode parts to fq2 (sampled) dataframe

    Return dataframe
    """
    bc_starts, bc_ends = get_amp_part_bounds(amp_seq)
    col_set = set(df.columns)
    seqs = df['seq']
    quals = df['qual']
    # Each barcode, starting from zero (0 = poly-N)
    n = 0
    for st,en in zip(bc_starts, bc_ends):
        if (en - st) > 0:
            bc_col = f"bc{n}"
            if fresh or (bc_col not in col_set):
                df[bc_col] = seqs.str.slice(bc_starts[n], bc_ends[n])

            qc_col = f"qc{n}"
            if fresh or (qc_col not in col_set):
                df[qc_col] = quals.str.slice(bc_starts[n], bc_ends[n])
        n += 1

    return df


def fq2_df_Q30_stats(fq2_df):
    """ Add Q30 stats

    Return (updated given) dict
    """
    new_stats = {}
    if 'qc0' in fq2_df.columns:
        new_stats['polyN_Q30'] = round(np.mean(fq2_df['qc0'].apply(seq_qual_score)), 3)
    new_stats['bc1_Q30'] = round(np.mean(fq2_df['qc1'].apply(seq_qual_score)), 3)
    new_stats['bc2_Q30'] = round(np.mean(fq2_df['qc2'].apply(seq_qual_score)), 3)
    new_stats['bc3_Q30'] = round(np.mean(fq2_df['qc3'].apply(seq_qual_score)), 3)
    return new_stats


def seq_qual_score(qual):
    """ Get Q30 score for list of quality srings
    """
    # Convert seq quality string into mean Q score
    # https://www.biostars.org/p/9463767/
    #
    # Pipeline = mean fraction "good" (Q30) bases
    m = np.mean([ord(c)>62 for c in qual])
    return(m)


### ------------------------------ Barcode triples --------------------------------

def sep_df_bci_cols(df, bc_wells=False, sublib=False, bc_wind=False, bc_bci=False, which=None):
    """ Separate dataframe complex barcode string into new columns

    df = cell dataframe with barcode wells 'bc_wells' as string triples '10_48_08'

    bc_wells = Flag to add wells; 'A1', 'D4', etc
    sublib   = Flag to add sublib, if present; If nothing, not added
    bc_wind  = Flag to add well indexes; As int
    bc_bci   = Flag to add bc indexes; As int

    For wells, need df['bc_wells']; should have composite indexes (e.g '26_55_60')
    For bcis, need df['bc_bcis']; should have composite indexes (e.g '26_55_60')

    Return dataframe
    """
    # If no list or set given, set all
    if not which:
        which = [1, 2, 3]
    if not isinstance(which, list):
        which = [which]

    # Get source of well info; Index or column
    if df.index.name == 'bc_wells':
        bcw_df = pd.Series(df.index, index=df.index)
    else:
        bcw_df = df['bc_wells']

    # Well strings
    if bc_wells:
        # First composite to to well int, then int to label
        if 1 in which:
            df['bc1_well'] = bcw_df.apply(cind_to_bc1_part).astype(int)
            df['bc1_well'] = df['bc1_well'].map(WIND_TO_WELL_DICT)
        if 2 in which:
            df['bc2_well'] = bcw_df.apply(cind_to_bc2_part).astype(int)
            df['bc2_well'] = df['bc2_well'].map(WIND_TO_WELL_DICT)
        if 3 in which:
            df['bc3_well'] = bcw_df.apply(cind_to_bc3_part).astype(int)
            df['bc3_well'] = df['bc3_well'].map(WIND_TO_WELL_DICT)

    # Sublib may / may not exist
    if sublib:
        #df['sublib'] = df['bc_wells'].apply(cind_to_sublib)
        df['sublib'] = bcw_df.apply(cind_to_sublib)
        # If sublib all empty, drop col
        if not len(df[df['sublib'].str.len() > 0]):
            df.drop('sublib', axis=1, inplace=True)

    # Well indexes
    if bc_wind:
        if 1 in which:
            df['bc1_wind'] = bcw_df.apply(cind_to_bc1_part).astype(int)
        if 2 in which:
            df['bc2_wind'] = bcw_df.apply(cind_to_bc2_part).astype(int)
        if 3 in which:
            df['bc3_wind'] = bcw_df.apply(cind_to_bc3_part).astype(int)

    # Barcode indexes
    if bc_bci:
        if 1 in which:
            df['bc1_int'] = df['bc_bcis'].apply(cind_to_bc1_part).astype(int)
        if 2 in which:
            df['bc2_int'] = df['bc_bcis'].apply(cind_to_bc2_part).astype(int)
        if 3 in which:
            df['bc3_int'] = df['bc_bcis'].apply(cind_to_bc3_part).astype(int)
    return df


# Composite index (e.g. well, barcode): b1_b2_b3__sub
def cind_to_bc1_part(r): return r.split('__')[0].split('_')[0]
def cind_to_bc2_part(r): return r.split('__')[0].split('_')[1]
def cind_to_bc3_part(r): return r.split('__')[0].split('_')[2]
def cind_to_sublib(r):
    slib = ''
    parts = r.split('__')
    if len(parts) > 1:
        slib = parts[1]
    return slib

# v0.9.7 header line as: w1_w2_w3__pt__i1_i2_i3__bc1_bc2_bc3__polyN__dstamp_sindex
# Combined well indexes, primer type, bc indexes, bc seqs, poly N, data stamp and sequencing index
# Record names like:
#   20_15_07__T__20_63_55__TTCAACAT_CTTCACAA_GGGCGAAG__TTATTCTTTG__220814EO_CAGATC

# Well index parts
def fqrec_to_bc_winds(r): return r.split('__')[0]
def fqrec_to_bc1_wind(r): return fqrec_to_bc_winds(r).split('_')[0]
def fqrec_to_bc2_wind(r): return fqrec_to_bc_winds(r).split('_')[1]
def fqrec_to_bc3_wind(r): return fqrec_to_bc_winds(r).split('_')[2]

def fqrec_to_ptype(r): return r.split('__')[1]

# Barcode index parts
def fqrec_to_bc_bcis(r): return r.split('__')[2]
def fqrec_to_bc1_bci(r): return fqrec_to_bc_bcis(r).split('_')[0]
def fqrec_to_bc2_bci(r): return fqrec_to_bc_bcis(r).split('_')[1]
def fqrec_to_bc3_bci(r): return fqrec_to_bc_bcis(r).split('_')[2]

# Barcode sequence parts
def fqrec_to_bc_seqs(r): return r.split('__')[3]
def fqrec_to_bc1_seq(r): return r.split('__')[3].split('_')[0]
def fqrec_to_bc2_seq(r): return r.split('__')[3].split('_')[1]
def fqrec_to_bc3_seq(r): return r.split('__')[3].split('_')[2]

# Poly-N part
def fqrec_to_polyN(r): return r.split('__')[4]

# Sequencing processing part
def fqrec_to_sproc(r): return r.split('__')[5]



### ------------------------------ misc --------------------------------

def add_suf_to_df_bci(df, suffix, pref='__s', cols=['bc_wells', 'bc_ints', 'cell_barcode'], index=False):
    """ Add index suffice to barcode cols in dataframe

    df = dataframe with barcode columns
    suffix = suffix to add to barcodes
    pref = string to append before appending suffix
    cols = list of columns to modify
    index = flag to apply suffix to index

    Return dataframe or nothing
    """
    # Index
    if index:
        # If cols also, check index name is in list
        if cols:
            match = False
            for c in cols:
                if df.index.name == c:
                    match = True
                    break
            if not match:
                print(f"Problem adding suffix to df; {cols} don't match index {df.index.name}")
                return None

        df.index = df.index + pref + str(suffix)
    else:
        # Each listed column
        for c in cols:
            if c not in df.columns:
                print(f"Problem adding suffix to df; {c} not in columns {df.columns}")
                return None
            df[c] = df[c] + pref + str(suffix)
    return df


def write_barcode_data(spipe, fpath):
    """ Write barcode data to output file

    Return 
    """
    kit_s, kit_n, kit_source = spipe.get_kit()
    story = f"barcode data; kit {kit_s} {kit_n}"
    ver = spipe.get_version()
    utils.file_header(ofile=fpath, story=story, ver=ver)

    # Cleaning barcodes to subset of types?
    clean_set = None
    if spipe.get_par_val('bc_save_data_clean', as_bool=True):
        clean_set = set("RT")

    bc_info = spipe.get_bc_info()
    header = True
    for i, name in enumerate(bc_info['bc_round_name']):
        if not name:
            continue
        with open(fpath, "a") as OUTFILE:
            print(f"# Round {i} {name}", file=OUTFILE)
        bc_df = bc_info['bc_data'][i]
        # Clean up barcode output set?
        if clean_set:
            bc_df = bc_df[bc_df['type'].isin(clean_set)]

        story = utils.write_df(bc_df, fpath, sep=',', header=header,
                                index=True, mode='a', verb=False)
        # Header for first only
        header = False

