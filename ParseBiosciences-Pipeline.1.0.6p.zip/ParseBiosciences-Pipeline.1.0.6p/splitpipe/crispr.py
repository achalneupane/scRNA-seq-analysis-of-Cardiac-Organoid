#
#   Copyright (c) 2023 Parse Biosciences
#
#   See company page for background information, usage instructions and license.
#   https://www.parsebiosciences.com/
#

import numpy as np
import pandas as pd
from sklearn.mixture import GaussianMixture


LOCAL_IMPORT=0

if LOCAL_IMPORT:
    import utils
else:
    from splitpipe import utils
    
    
# gRNA clean up --------------------------------------------------------------

def filter_tas_via_mixmod(spipe, tas_df, tscp_modals=2):
    """ Filter transcript assignment via mixture model
        
    tas_df = transcript assignment dataframe, pre-filtred for min-reads-per-tscp, min-tscp-per-gene

    Filtered output intended for DGE processing for focal gRNA
        
    Return dict with dataframe and stats
    """    
    #Get transcript counts and log it
    tscp_indf = tas_df.groupby(["bc_wells", "gene"]).agg({'polyN':["size"]})
    tscp_indf.columns = ["tscp_cnt"]
    tscp_indf["log_tscp_cnt"] = np.log2(tscp_indf.tscp_cnt)

    rseed = spipe.get_par_val('rseed', as_int=True)

    #Gaussian mixed model
    gmm = GaussianMixture(n_components=tscp_modals, random_state=rseed)
    gmm.fit(tscp_indf.log_tscp_cnt.values.reshape(-1,1))
    tscp_indf['target_class'] = gmm.predict(tscp_indf.log_tscp_cnt.values.reshape(-1, 1))
    
    #Filter to keep bigger modal
    keep_class = 99999
    mean_trk = 0
    for i in tscp_indf.target_class.unique():
        mean = tscp_indf[tscp_indf.target_class == i]["log_tscp_cnt"].mean()
        if mean > mean_trk:
            keep_class = i
            mean_trk = mean        
    keep_tscp_indf = tscp_indf[tscp_indf['target_class'] == keep_class]
    
    # Mask input
    df = tas_df.set_index(['bc_wells', 'gene'])
    filt_tas_df = df.loc[keep_tscp_indf.index.tolist()]
    # Flatten multi-index from bc_wells and gene grouping with reset
    filt_tas_df = filt_tas_df.reset_index()
    
    # Some stats
    tscp_cutoff = keep_tscp_indf['tscp_cnt'].min()
    
    # Package output
    new_dict = {'filter_tas': filt_tas_df,
                'tscp_cutoff': tscp_cutoff,
                'num_in_tscp': len(tas_df),
                'num_out_tscp': len(filt_tas_df),
    }
    return new_dict


# util / io --------------------------------------------------------------
def g2cell_dict_from_df(df, g_col='guide', c_col='bc_wells'):
    """ Get guide / gene to cell mapping dict from dataframe

    Return dict
    """
    # If guides are index, create col with these
    add_col = False
    if df.index.name == g_col:
        df[g_col] = df.index
        add_col = True
                
    new_dict = {}
    for gene in sorted(df[g_col].unique()):
        new_dict[gene] = sorted(list(df[df[g_col] == gene][c_col]))
        
    # If added col, drop it
    if add_col:
        df.drop(columns=[g_col], inplace=True)
    
    return new_dict


# call mkref --------------------------------------------------------------
def get_mkref_focal_script(spipe):
    """ Get paths for call to mkref-script for gfasta focal 

    Return tuple of paths
    """
    # Top level package path
    path = spipe.get_pkg_path()
    call_path = f"{path}/scripts/mkref_focal_genome.sh"
    par_path = f"{path}/scripts/config/CRISPR-focal_spipe.par"

    return call_path, par_path


def run_focal_gfasta_mkref(spipe):
    """
    """
    spipe.report_run_story(f"Checking if can run gfasta directly")
    
    gfasta = spipe.get_par_val('gfasta', as_list=True)
    is_focal = spipe.is_focal_crispr()

    if (not is_focal) or (not gfasta):
        story = f"No gfasta direct run: focal = {is_focal}, gfasta len {len(gfasta)}"
        spipe.report_run_story(story)
        return True

    script_path, par_path = get_mkref_focal_script(spipe)
    output_dir = spipe.filepath('DIR_PROC_FB_GENO', None)
    gname, fasta = gfasta[:2]

    # Possibly clean up fasta path
    fasta = utils.fname_full_path(path)

    # Cook up command line
    command = ' '.join([script_path, gname, fasta, output_dir, par_path])

    ok, callout, ex_story = utils.call_exec(command, shell=True, verb=True)
    # Story to log only (call verb=True already prints outcome)
    spipe.report_run_story(ex_story, to_log=True)

    return ok

