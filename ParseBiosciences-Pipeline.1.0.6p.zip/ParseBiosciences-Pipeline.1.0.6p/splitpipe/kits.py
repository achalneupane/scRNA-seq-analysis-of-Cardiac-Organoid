#
#   Copyright (c) 2023 Parse Biosciences
#
#   See company page for background information, usage instructions and license.
#   https://www.parsebiosciences.com/
#
# Kit related functions

import pandas as pd


LOCAL_IMPORT=0

if LOCAL_IMPORT:
    import utils
else:
    from splitpipe import utils


### ----------------------------- Kit definitions -----------------------------

KIT_CHEM_DEFS = """
    kit       chem  nwells  bc1     bc2      bc3    ktype
    custom    v0    1       NA      NA       NA     special
    WT_mini   v1    12      n24_v4   v1       v1    normal
    WT_mini   v2    12      n24_v4   v1       v1    normal
    WT        v1    48      v2       v1       v1    normal
    # WT      v2    48      n96_v4   v1       v1    normal
    WT        v2    48      n99_v5   v1       v1    normal
    # WT_mega v1    96      n192_v4  v1       v1    normal
    # WT_mega v2    96      n192_v4  v1       v1    normal
    WT_mega   v1    96      n198_v5  v1       v1    normal
    WT_mega   v2    96      n198_v5  v1       v1    normal
"""


def _make_kit_chem_tab_df():
    """ Get kit / chemistry table as dataframe
    """
    head_row = []
    rows = []
    for line in KIT_CHEM_DEFS.split('\n'):
        parts = line.split('#')[0].split()
        if parts:
            if head_row:
                rows.append(parts)
            else:
                head_row = parts

    kit_df = pd.DataFrame(rows, columns=head_row)
    kit_df['nwells'] = kit_df['nwells'].astype(int)
    return kit_df


# Create once as global
KIT_CHEM_TAB = _make_kit_chem_tab_df()


### ----------------------------- Kit functions -----------------------------


def custom_kit(kit):
    """ Is given kit custom?
    """
    custom = False
    if str(kit).lower().startswith('custom'):
        custom = True
    else:
        ok, n = utils.str_to_num(kit, regex=False)
        if ok and (n == 1):
            custom = True
    return custom


def kit_chem_from_int(kint, chem='v2'):
    """ Get kit from int based on number of wells, maybe chemistry

    chem = chemistry specification

    Return list of lists [[kit,chem], ]
    """
    if custom_kit(kint):
        chem = ''

    k_list = []
    # If given chemistry, make sure it's good
    if chem:
        chem_s = parse_chemistry(chem)
        if not chem_s:
            if verb:
                print(f"Bad chemistry ({chem}) given for kit_chem_from_int({kint})")
            return k_list
        chem = chem_s

    # Make sure starting with int; No regex, only simple int should work
    ok, n = utils.str_to_num(kint, regex=False)
    if ok:
        # Subset of rows by wells (int) and maybe chem (str)
        df = KIT_CHEM_TAB[KIT_CHEM_TAB['nwells'] == n]
        if chem:
            df = df[df['chem'] == chem]
        k_list = [list(t) for t in df[['kit', 'chem']].values]

    return k_list


def parse_kit(kit, chem='v2', strict=False):
    """ Attempt to parse given kit, and maybe chemistry, into cannonical form

    In cases where the name along is ambiguous, chemistry must be specified

    Return str, story
    """
    if custom_kit(kit):
        return 'custom', ''

    # Make sure kit is string (e.g. in case given int)
    kit_s = str(kit)
    # If given chemistry, make sure it's good
    if chem:
        chem_s = parse_chemistry(chem)
        if not chem_s:
            return None, f"Bad chemistry ({chem}) given for parse_kit({kit})"
        chem = chem_s

    story = ''
    k_list = []
    # Lowercase and in case dash rather than underscore (e.g. WT-mega >--> WT_mega)
    if not strict:
        # Try to parse number first
        k_list = kit_chem_from_int(kit_s, chem=chem)
        if len(k_list) < 1:
            # Not int so get name matches
            kit_s = kit_s.replace('-', '_').lower()
            df = KIT_CHEM_TAB[KIT_CHEM_TAB['kit'].str.lower() == kit_s]
            if chem:
                df = df[df['chem'] == str(chem)]
            k_list = [list(t) for t in df[['kit', 'chem']].values]
    else:
        df = KIT_CHEM_TAB[KIT_CHEM_TAB['kit'] == kit_s]
        if chem:
            df = df[df['chem'] == str(chem)]
        k_list = [list(t) for t in df[['kit', 'chem']].values]

    # Different story for different number of matches
    if len(k_list) < 1:
        kit_s = ''
        story = f"Kit '{kit}' unrecognized"
    elif len(k_list) > 1:
        kit_s = ''
        story = f"Kit '{kit}' ambiguous; [kit,chem] = {k_list}"
    else:
        kit_s, chem = k_list[0]

    return kit_s, story


def parse_chemistry(chem, as_int=False):
    """ Parse given chemistry to standard form

    Return str or int
    """
    # Get number
    ok, n = utils.str_to_num(chem, regex=True)
    if ok:
        chem = f"v{n}"
        if chem in KIT_CHEM_TAB['chem'].values:
            if as_int:
                chem = n
            return chem


def kit_name_list(chem='v2', as_list=False, ktype='normal'):
    """ Get list of kits

    chem = chemistry specification
    as_list = flag to return list with [kit,chem] items
    ktype = filter for kit type column

    Return list[kit,] or list of [[kit, chem],]
    """
    # Filter table on any restrictions
    df = KIT_CHEM_TAB
    if chem:
        chem = parse_chemistry(chem)
        df = df[df['chem'] == str(chem)]
    if ktype:
        df = df[df['ktype'] == ktype]
    # Returning list of only kit or [kit, chem]
    if as_list:
        k_list = [list(t) for t in df[['kit', 'chem']].values]
    else:
        k_list = list(df['kit'].unique())
    return k_list


def chem_for_kit(kit):
    """ Get list of chemistry for (cannonical named) kit

    Return list[chem]
    """
    # Filter table on any restrictions
    df = KIT_CHEM_TAB
    df = df[df['kit'] == kit]
    k_list = list(df['chem'].unique())
    return k_list


def plate_rows_for_kit(kit, chem='v2'):
    """ Number of plate rows for kit

    Return int
    """
    n = 0
    kit, _ = parse_kit(kit, chem=chem)
    if kit == 'WT_mega':
        n = 8
    elif (kit == 'WT'):
        n = 4
    elif kit == 'WT_mini':
        n = 1
    return n


def nwell_for_kit(kit, chem='v2'):
    """ Get nwell (int) for kit

    chem = chemistry version

    Return int
    """
    if custom_kit(kit):
        nwell = 1
    else:
        # Filter table on any restrictions
        df = KIT_CHEM_TAB
        df = df[df['kit'] == kit]
        if chem:
            chem = parse_chemistry(chem)
            df = df[df['chem'] == str(chem)]
        k_set = set(df['nwells'])
        nwell = 0 if len(k_set) > 1 else list(k_set)[0]
    return nwell


def kit_bc_set_list(kit, chem, as_tup=True, zero_pad=True):
    """ Get list of barcode set names for kit and chemistry

    kit = kit name
    chem = chemistry version
    as_tup = flag to return list of [bcX, name] items vs names
    zero_pad = flag to preface list so that barcode rounds match list index

    Return list of barcode names per round
    """
    bc_list = []
    # Parse first
    chem = parse_chemistry(chem)
    kit_s, _ = parse_kit(kit, chem=chem)
    if kit_s and chem:
        df = KIT_CHEM_TAB
        row = df[(df['kit'] == kit_s) & (df['chem'] == str(chem))]
        cols = [f"bc{r}" for r in '123']
        bc_list = list(df.loc[row.index, cols].values.flatten())
        # Tuple as [bcX, name]?
        if as_tup:
            new_list = []
            for col, bc in zip(cols, bc_list):
                new_list.append([col, bc])
            bc_list = new_list
        # Zero pad (so barcode round = index; e.g. 1 = bc1, 2 = bc2...)
        if zero_pad:
            if as_tup:
                bc_list = [['bc0', None]] + bc_list
            else:
                bc_list = [None] + bc_list
    return bc_list


def kit_round1_bc_dict(chem):
    """ Get dict mapping kit to name of round1 barcode set

    chem = chemistry version

    Return dict[kit] = r1bc
    """
    new_dict = {}
    k_list = kit_name_list(as_list=True, chem=chem)
    for kit, chem in k_list:
        bc_list = kit_bc_set_list(kit, chem, as_tup=False, zero_pad=True)
        new_dict[kit] = bc_list[1]
    return new_dict


def report_valid_kits(chem=None, ktype='normal', pad=True):
    """ Report kit collection; If not given chemistry, report that too
    """
    # List of kit names, possibly limited to chem and ktype
    k_list = kit_name_list(as_list=False, chem=chem, ktype=ktype)

    if pad:
        print()
    print(f"There are {len(k_list)} installed kits:\n")
    for kit in k_list:
        n_wells = nwell_for_kit(kit)
        c_list = chem_for_kit(kit)
        chemistry = ', '.join(c_list)
        print(f"    {kit:12s} {n_wells} wells,   Chemistry: {chemistry}")
    if pad:
        print()


##### -------------------------- BC scoring -----------------------
def bc_count_kit_score(counts, bc_set, remain_frac=0.2, verb=False):
    """ Calculate the score of fastq barcode seq counts for given barcode set

    counts = ranked barcode counts; e.g. series from df['bc1'].value_counts()
    bc_set = set of barcode sequences

    Return score
    """
    # Split counts into first and remaining parts
    # First part of counts = top N-bc counts
    f_tot = len(bc_set)
    f_counts = counts.iloc[:f_tot]
    f_num = len(set(f_counts.index) & bc_set)
    f_frac = f_num / f_tot
    f_mean = f_counts.mean()

    # Remaining part of counts via slice and threshold
    r_counts = counts.iloc[f_tot:]
    # Thresh = fraction of values in first part
    r_thresh = f_mean * remain_frac
    r_counts = r_counts[r_counts >= r_thresh]
    r_tot = len(r_counts.index)

    # None case
    if r_tot < 1:
        r_num = 0
        r_mean = r_frac = 0
    else:
        r_num = len(set(r_counts.index) & bc_set)
        r_frac = r_num / r_tot
        r_mean = r_counts.mean()

    if verb:
        print(f_tot, f_mean, r_thresh, sep='\t')
        print(f_num, f_frac, f_mean, sep='\t')
        print(r_num, r_frac, r_mean, sep='\t')

    score = f_frac - r_frac
    return score
