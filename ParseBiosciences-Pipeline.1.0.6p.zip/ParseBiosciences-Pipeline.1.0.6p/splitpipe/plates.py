#
#   Copyright (c) 2023 Parse Biosciences
#
#   See company page for background information, usage instructions and license.
#   https://www.parsebiosciences.com/
#

import re
import numpy as np
import pandas as pd


LOCAL_IMPORT=0

if LOCAL_IMPORT:
    import bcutils
    import kits
    import utils
else:
    from splitpipe import bcutils
    from splitpipe import kits
    from splitpipe import utils


# Defines for (96 well) plates
ROW_LABS = list('ABCDEFGH')
COL_LABS = [str(i+1) for i in range(12)]
PLATE_N_ROWS = len(ROW_LABS)
PLATE_N_COLS = len(COL_LABS)

# Mapping rows to 0-based coords
row_letter_to_number = dict(zip(ROW_LABS, [i for i in range(PLATE_N_ROWS)]))

# Mapping plate 0-base coords to well string; e.g. (1,3) >--> B4
well_coords_to_str = {}
for i,row in enumerate(ROW_LABS):
    for col in range(PLATE_N_COLS):
        well = f"{row}{col+1}"
        coords = (i, col)
        well_coords_to_str[coords] = well


# ----------------- Parse well specification to well indexs ----------------

# Well definition regex match patterns
# Single well, Colon:range, Dash-range; Get letter and number separate
WELL96_1_REGEX = re.compile(r'([ABCDEFGH])([1-9]|1[012])$')
WELL96_C_REGEX = re.compile(r'([ABCDEFGH])([1-9]|1[012]):([ABCDEFGH])([1-9]|1[012])$')
WELL96_D_REGEX = re.compile(r'([ABCDEFGH])([1-9]|1[012])-([ABCDEFGH])([1-9]|1[012])$')


def parse_96wells(s):
    """ Parse well specification string into well indexes

    s = well specification; e.g. 'A4,C5:D8'

    Parses well specs into list of 1-based well indexes

    Return tuple (status, list, story)
    """
    ok = True
    story = ''

    wells = np.arange(96, dtype=int).reshape(8, 12)
    sub_wells = []
    # Try will fail on non-match cases that are processed with checks
    try:
        blocks = s.upper().split(',')
        for b in blocks:
            if ':' in b:
                vals = unpack_well_match(WELL96_C_REGEX.match(b), 4)
                s_row = row_letter_to_number[vals[0]]
                s_col = vals[1] - 1
                e_row = row_letter_to_number[vals[2]]
                e_col = vals[3]
                sub_wells += list(wells[s_row:e_row+1, s_col:e_col].flatten())
            elif '-' in b:
                vals = unpack_well_match(WELL96_D_REGEX.match(b), 4)
                s_row = row_letter_to_number[vals[0]]
                s_col = vals[1] - 1
                e_row = row_letter_to_number[vals[2]]
                e_col = vals[3] - 1
                sub_wells += list(np.arange(wells[s_row, s_col], wells[e_row, e_col]+1))
            else:
                vals = unpack_well_match(WELL96_1_REGEX.match(b), 2)
                s_row = row_letter_to_number[vals[0]]
                s_col = vals[1] - 1
                sub_wells += [wells[s_row, s_col]]
        sub_wells = list(np.unique(sub_wells))
    except Exception as e:
        ok = False
        story = f"Problem well def: '{b}' from '{s}'"
        pass

    if ok:
        # Convert to 1-base
        sub_wells = [i + 1 for i in sub_wells]
    else:
        sub_wells = []

    return (ok, sub_wells, story)


def unpack_well_match(mat, num):
    """ Unpack well regex match with two or four items [letter, well, [letter, well]]
    """
    vals = []
    if num == 2:
        vals = [mat[1], int(mat[2])]
    elif num == 4:
        vals = [mat[1], int(mat[2]), mat[3], int(mat[4])]
    return vals


def wells_for_96plate(rows=0, kit=None, as_wind=False):
    """ Get list of wells for 96 well plate

    Return list
    """
    wells = []
    # How many plate rows?
    if kit:
        max_row = kits.plate_rows_for_kit(kit)
    else:
        max_row = PLATE_N_ROWS if rows == 0 else rows

    for r, row in enumerate(ROW_LABS):
        if r >= max_row:
            break
        for col in range(PLATE_N_COLS):
            wells.append(f"{row}{col+1}")

    # If as well indices?
    if as_wind:
        wind_list = []
        for w in wells:
            wind_list.append(bcutils.WELL_TO_WIND_DICT[w])
        wells = wind_list

    return wells


def num_wells_for_96plate(kit):
    """ Number of wells for given kit
    """
    wells = wells_for_96plate(kit=kit)
    return len(wells)


# ----------------- Conversion utils ------------------------------------

def well_index_to_str(wind, sort=True, minimize=False):
    """ Get string for well index; e.g. 15:17 >--> 'B4:B6'

    wind = (1-based) plate well index or list or set of these
    sort = flag to sort (simple, non-minimized) list
    minimize = flag to run minimization algorithm

    If minimize
        Try to minimize well specification via block algorithm
    Else
        Generate simple comma,sep,list of wells: e.g 'A1,A2,A3,A4'

    return str
    """
    well = ''
    # If given a list, process each index
    if isinstance(wind, list) or isinstance(wind, set):
        # Minimize specs
        if minimize:
            plate_df = get_plate_df(val=0)
            plate_df = mark_plate_wells(plate_df, wind, mark=1)
            well = plate_one_samp_well_specs(plate_df, 1)
        # Enumerate well index list
        else:
            well_list = []
            if sort:
                wind = sorted(list(wind))
            for i in wind:
                well_list.append(well_index_to_str(i))
            well = ",".join(well_list)
    # Single well index
    else:
        well = bcutils.WIND_TO_WELL_DICT[wind]
    return well


# ----------------- Plate as dataframe ------------------------------------

def get_plate_df(row_labs=ROW_LABS, col_labs=COL_LABS, val=0):
    """ Get 96-well plate dimensioned dataframe

    Return dataframe
    """
    plate_df = pd.DataFrame(np.zeros((len(row_labs), len(col_labs))), index=row_labs, columns=col_labs)
    # Possibly replace zero with value and cast to int
    plate_df = plate_df.replace(0, val).astype(int)
    return plate_df


def mark_plate_wells(plate_df, wind_list, mark=1, non_mark=None):
    """ Mark plate dimensioned dataframe with well indexes

    plate_df = plate dataframe
    wind_list = well indexes; 1-based coords
    mark = value to mark sample wells
    non_mark = value to mark non-sample wells

    return dataframe
    """
    # Setting background?
    if non_mark is not None:
        plate_df[:] = non_mark
    # indexes one at a time
    for wind in wind_list:
        r = int((wind - 1) / PLATE_N_COLS)
        c = (wind - 1) % PLATE_N_COLS
        row = ROW_LABS[r]
        col = COL_LABS[c]
        #print(wind, r, c, row, col, sep='\t')
        plate_df.at[row, col] = mark

    return plate_df


# ----------------- Plate (marked) to well specification -------------------

def plate_samp_well_specs(wells_df):
    """ Parse plate well dataframe into per-sample well specification strings

    wells_df = plate dimensioned dataframe with samples marked by int > 0

    Each sample (unique pos int in 'plate') gets a sample spec str (e.g. 'A5:D8')

    Return list str (spec per sample)
    """
    # Copy dataframe, as this gets set to zero to track well settings
    wells_df = wells_df.copy()
    wspec_list = []
    # Samples denoted by numbers in dataframe, 1,2.. max; Unset / consumed = zero
    samp_nums = sorted([x for x in set(wells_df.values.flatten()) if x > 0])
    for snum in samp_nums:
        well_spec = plate_one_samp_well_specs(wells_df, snum)
        wspec_list.append(well_spec)
    return wspec_list


def plate_one_samp_well_specs(wells_df, snum):
    """ Parse plate well dataframe for single sample well specification string

    wells_df = plate dataframe with samples marked by int > 0
    snum = int number for sample to consider

    return str
    """
    # Total wells for this sample
    snum_wells = num_snum_wells(wells_df, snum)
    well_def_list = []
    # Cook up 'blocks' of wells while any remain
    while snum_wells > 0:
        # Start coord for block
        st_coords = find_snum_well_start(wells_df, snum)
        if not st_coords:
            break
        # End coord and count; This modifies wells dataframe
        en_coords, num = mark_snum_well_block(wells_df, snum, st_coords, mark=0)
        if not en_coords:
            break
        snum_wells -= num
        # Save well block string
        wspec = well_block_str(st_coords, en_coords)
        well_def_list.append(wspec)
    # Final well spec for sample = comma,delim,list of well block strings
    well_spec = ','.join(well_def_list)
    return well_spec


def find_snum_well_start(wells_df, snum):
    """Find first well with given sample number

    Return coord tuple (row,col)
    """
    rows, cols = wells_df.shape
    for r in range(rows):
        for c in range(cols):
            if wells_df.iloc[r,c] == snum:
                return (r,c)
    return None


def count_snum_well_run(wells_df, snum, st_coords, down_col=False):
    """Find run of wells matching sample number, across or down from start (row,col)

    wells_df = plate dimensioned dataframe with samples marked by int
    snum = target sample int to count

    Return num
    """
    rows, cols = wells_df.shape
    st_row, st_col = st_coords
    if (not (0 <= st_row < rows)) or (not (0 <= st_col < cols)):
        return 0
    num = 0
    if down_col:
        for r in range(st_row, rows):
            if wells_df.iloc[r,st_col] == snum:
                num += 1
            else:
                break
    else:
        for c in range(st_col, cols):
            if wells_df.iloc[st_row,c] == snum:
                num += 1
            else:
                break
    return num


def mark_snum_well_block(wells_df, snum, st_coords, mark=0):
    """Mark out well block for sample number starting from plate coords

    wells_df = plate dimensioned dataframe with samples marked by int
    snum = target sample int to count

    Return end (row,col) tuple and number of wells marked
    """
    # Unpack bounds and starting row,col
    max_row, max_col = wells_df.shape
    st_row, st_col = st_coords
    #print(f"Dim {max_row}, {max_col}, snum={snum}, start = {st_coords}")
    # Init
    en_row = en_col = -1
    num = 0

    # Runs of snum down rows or cols
    col_run = count_snum_well_run(wells_df, snum, st_coords)
    row_run = count_snum_well_run(wells_df, snum, st_coords, down_col=True)
    #print(f" row_run {row_run}, col_run {col_run}")
    # Nothing either direction?
    if max(row_run, col_run) < 1:
        return None,0

    # Go with the bigger of row or col to mark at a time
    if col_run > row_run:
        #print(f"Setting by row, {col_run} cols at a time")
        # Set by row, col_run at a time
        en_col = st_col + col_run
        row = st_row
        n = col_run
        while n == col_run:
            #print("Setting", row, ",", st_col, en_col)
            wells_df.iloc[row, st_col:en_col] = mark
            en_row = row
            row += 1
            if row >= max_row:
                break
            n = count_snum_well_run(wells_df, snum, (row, st_col), down_col=False)
            num += col_run
        # End col reduced to be inclusive (i.e. last == en_col)
        en_col -= 1
    else:
        #print(f"Setting by col, {row_run} rows at a time")
        # Set by col, row_run at a time
        en_row = st_row + row_run
        col = st_col
        n = row_run
        while n == row_run:
            #print("Setting", st_row, en_row, ",", col)
            wells_df.iloc[st_row:en_row, col] = mark
            en_col = col
            col += 1
            if col >= max_col:
                break
            n = count_snum_well_run(wells_df, snum, (st_row, col), down_col=True)
            num += row_run
        # End row reduced to be inclusive (i.e. last == en_row)
        en_row -= 1

    return (en_row,en_col), num


def num_snum_wells(wells_df, snum):
    """ Return count of wells matching sample number

    wells_df = plate dimensioned dataframe with samples marked by int
    snum = target sample int to count

    """
    if snum < 0:
        num = (wells_df > 0).values.flatten().sum()
    else:
        num = (wells_df == snum).values.flatten().sum()
    return num


def well_block_str(st_coords, en_coords=None):
    """ Get string to specify plate wells in block from st to en coords

    Return string
    """
    # Pair of coords, start (top left) to end (bottom right)
    if en_coords:
        st_row, st_col = st_coords
        en_row, en_col = en_coords
        # Start well alone via recur
        st_str = well_block_str(st_coords)
        # Same well so just one; recur
        if (st_row == en_row) and (st_col == en_col):
            wspec = st_str
        else:
            en_str = well_block_str(en_coords)
            # If one row, dash, else colon
            sep = '-' if st_row == en_row else ':'
            wspec = st_str + sep + en_str
    # Single coord
    else:
        wspec = well_coords_to_str.get(st_coords, '')
    return wspec
