#
#   Copyright (c) 2023 Parse Biosciences
#
#   See company page for background information, usage instructions and license.
#   https://www.parsebiosciences.com/
#

import os
import sys
import re
import traceback
import math
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.colors as colors
import matplotlib.ticker as tickr
import matplotlib.cm as cmx
import matplotlib.colors as mc
import colorsys
import seaborn as sns
import base64
import jinja2
import anndata
import multiprocessing as mp
from collections import OrderedDict
from scipy.sparse import csc_matrix

LOCAL_IMPORT=0

if LOCAL_IMPORT:
    import pb_const as const
    import utils
else:
    from splitpipe import pb_const as const
    from splitpipe import utils


# ---------------------------------------------------------------------------
def have_reports_ins(spipe, verb=True, samp=None):
    """Check if reports inputs exist

    Return True/False, list of files
    """
    ok = False
    check_files = []
    # Files for given or all samples
    if samp:
        # All stats
        check_files.append(spipe.filepath('SFR_ALLSTATS', samp))
        # Analysis (clustering) info; Not for TCR
        if not spipe.is_tcr():
            check_files.append(spipe.filepath('SFR_ANA_PROC_DEF', samp))
    else:
        for samp in spipe.get_samples():
            check_files.append(spipe.filepath('SFR_ALLSTATS', samp))
            if not spipe.is_tcr():
                check_files.append(spipe.filepath('SFR_ANA_PROC_DEF', samp))
    # If list is good, we have inputs
    if utils.check_infile(check_files, verb=verb):
        ok = True
    return ok, check_files


def have_reports_outs(spipe, verb=False, samp=None):
    """Check if reports output files exist

    Return True/False, list of files
    """
    ok = False
    check_files = []
    # HTML files
    if samp:
        check_files.append(spipe.filepath('SF_ASUM_HTML', samp))
    else:
        for samp in spipe.get_samples():
            check_files.append(spipe.filepath('SF_ASUM_HTML', samp))
    # If list is good, we have outs
    if utils.check_infile(check_files, verb=verb):
        ok = True
    return ok, check_files


def run_reports(spipe):
    """ Run reports step

    Return status
    """
    spipe.report_proc_step("Reports")
    # Input and output status and list
    # If keep_going, input checks are per sample (ignore here)
    if spipe.keep_going():
        i_ok = True
    else:
        i_ok, i_list = have_reports_ins(spipe)
    o_ok, o_list = have_reports_outs(spipe)
    # Run only if don't have output or fresh
    if (not o_ok) or spipe.force_fresh_files():
        if not i_ok:
            bad_list = utils.bad_infile_list(i_list)
            story = f"Don't have inputs for report: {bad_list}"
            spipe.set_problem(story)
        else:
            generate_all_html_reports(spipe)
    else:
        spipe.report_run_story(f"Skipping Reports and using existing outputs")
        spipe.report_run_story2(f"Outputs: {o_list}")

    clean_up(spipe)
    ok = spipe.no_problems()
    spipe.report_proc_step("Reports", status=ok)
    return ok


def generate_all_html_reports(spipe):
    """ Function to loop through every sample and process

    If any problems, these are reported / remembered; Nothing returned
    """
    # Each sample
    samp_list = spipe.get_samples()
    for i, samp in enumerate(samp_list):
        ok = True
        spipe.report_run_story('')
        story = f"Report processing sample ({i+1} of {len(samp_list)}) {samp.get_name()}"
        spipe.report_run_story(story)
        spipe.report_run_mem(story=f"Report samp {i+1}")

        # Have required inputs?
        i_ok, i_list = have_reports_ins(spipe, samp=samp)
        if not i_ok:
            ok = False
            bad_list = utils.bad_infile_list(i_list)
            story = f"Don't have inputs for report: {bad_list}"
            spipe.set_problem(story)
        else:
            # Catch possible problems (e.g. plotting, scanpy ...)
            try:
                if spipe.is_tcr():
                    ok = generate_single_tcr_html_report(spipe, samp)
                else:
                    ok = generate_single_html_report(spipe, samp)
            except Exception as e:
                ok = False
                # Dump traceback, stdout and log
                traceback.print_exc(file=sys.stdout)
                sys.stdout.flush()
                traceback.print_exc(file=spipe.get_log_fh())
                story = f"Failed generate_single_html_report: {e}"
                spipe.set_problem(story)
                
        # Handle possible post processing (e.g. merging new with parent html)
        if ok:
            ok = post_proc_html_report(spipe, samp)

        # Problem? report / possibly bail
        if not ok:
            story = f"Report problem with sample {samp.get_name()}"
            spipe.set_problem(story)
            if spipe.keep_going():
                spipe.report_run_story("Keep-going True... So, keep on going!")
                spipe.clear_problems()
                print()
            else:
                break


def generate_single_html_report(spipe, samp):
    """ Generate html report for one sample; Content depends on loaded files

    Returns status; Outputs saved to files
    """
    # Various things depend on targeted and/or focal barcoding
    targeted = spipe.is_targeted()
    focal = spipe.is_focal_crispr()

    # Load info and anndata with clusters, etc
    ana_info, adata = load_samp_analysis(spipe, samp)
    # Have to at least have a status (i.e. file from analysis step)
    if not ana_info['status']:
        spipe.set_problem(f"No analysis done for sample {samp.get_name()}")
        return False

    clust_alg = ana_info['cluster_alg']
    min_bc = ana_info['cluster_min_bc']
    n_cells, n_genes = adata.shape
    # This used if too few cells / genes for plot; Status added below
    warning_json = {'n_cells': n_cells, 'n_genes': n_genes, 'min_bc': min_bc}

    # Stats; All stats dataframe
    stat_df = spipe.get_stats_data(samp)
    if spipe.have_parent():
        # Parent dir data
        par_dir = spipe.get_parent_info(key='path')
        par_stat_df = spipe.get_stats_data(samp, top_dir=par_dir)
    else:
        par_stat_df = None

    # Package jinja vars for pipeline
    pipeline_json = get_pipeline_json(spipe, samp)

    # statistics collection for report display
    spipe.report_run_story2(f"Collecting stats to report")
    stat_list = get_report_stats_kv_list(spipe, samp, stat_df, targeted=targeted, focal=focal)

    sum_json = {
        'stat_list': stat_list,
        'cur_samp_name': samp.get_name(),
        'cur_samp_wells': samp.get_wells(),
        'cur_samp_nsublibs': samp.num_sublibs(),
    }

    # ============ html / jinja ==========
    # output filename
    rendered_file_path = spipe.filepath('SF_ASUM_HTML', samp)
    # Input HTML templates for jinja2
    template_filename = "templates/template.html.j2"
    script_path = spipe.get_pkg_path()
    template_file_path = os.path.join(script_path, template_filename)

    logo = get_logo_img(spipe)
    checkbox = get_chk_img(spipe)

    # Init jinja vars to dummy values
    umap_json = 'umap_json'

    # ============ Independent of clusering ==========
    spipe.report_run_story2(f"Generating plate figures")
    plates_json = plot_plates(spipe, samp, targeted=targeted, focal=focal)

    # Sequencing saturation figures
    spipe.report_run_story2(f"Generating subsample plots")
    tscp_json = plot_gt_subsamp(spipe, samp, tscp=True, targeted=targeted)
    gene_json = plot_gt_subsamp(spipe, samp, tscp=False, targeted=targeted)
    sat_json = {'tscp_sat': tscp_json, 'gene_sat': gene_json}

    # Get values for ploty figures on pg1 of report
    # "Identified cells" Transcript -vs- sorted BC fig
    spipe.report_run_story2(f"Generating tscp cell count figure")
    bc_rank_json = plot_bc_rank(spipe, samp, stat_df, targeted=targeted, par_stat_df=par_stat_df)

    # Barnyard plot
    if spipe.num_genomes() > 1:
        if spipe.get_par_val('rep_save_figs', as_bool=True):
            spipe.report_run_story2("Generating barnyard plot")
            plot_barnyard(spipe, samp)

    # ============ Depends on cell-gene cluster data ==========
    # Cluster status var:
    #   0 = all good, clusters to show
    #   1 = too few cells
    #   2 = some other (scanpy) error, preventing cluster page

    # Use cluster number to determine if we have cluster data
    # focal also; Get's subsample from parent
    if focal or (int(ana_info.get('cluster_num', 0)) > 0):
        clust_status = 0
        # Doesn't return anything; Table written to temporary file
        spipe.report_run_story2("Rendering gene enrichment table (pb)")
        render_clus_gene_tab(spipe, samp)

        from_parent = True if focal else False

        # Cell subsample for UMAP plots; If no subsampling, adata is just returned
        adata = get_umap_pl_cell_subsamp(spipe, samp, adata, from_parent=from_parent)
        umap_json = plot_umap(spipe, samp, adata, ana_info, targeted=targeted)
    else:
        if 'too_few' in ana_info['status']:
            clust_status = 1
            story = f"Too few cells; No clustering: {adata.shape}"
            spipe.report_run_story(story)
        else:
            clust_status = 2
            story = f"No clustering data: {ana_info['status']}"
            spipe.report_run_story(story)
    warning_json['clust_status'] = clust_status

    # If problem with clustering, still need fields for output processing
    if clust_status > 0:
        adata.obs[clust_alg] = list(range(0, n_cells))
        fpath = spipe.filepath('TMP_DIFF_TAB_HTML', samp)
        with open(fpath, 'w') as OFILE:
            print("<!-- empty temp diff expression html -->",file=OFILE)
            spipe.report_run_story2(f"Wrote empty gene clust html: {fpath}")

    # Cluster 'names' for selection legend; Unique (short, sorted list)
    clust_names = get_cell_cluster_names(spipe, samp, adata, ana_info, unique=True, as_str=True)
    # Get both file name and path; jinja uses separatately
    diff_table_path, diff_table_file = spipe.fileparts('TMP_DIFF_TAB_HTML', samp)

    environment = jinja2.Environment(loader=jinja2.FileSystemLoader([script_path, diff_table_path]))

    output_text = environment.get_template(template_filename).render(
        pipeline_json=pipeline_json,
        diff_table_file=diff_table_file,
        bc_rank_json=bc_rank_json,
        warning_json=warning_json,
        clust_names=clust_names,
        plates_json=plates_json,
        umap_json=umap_json,
        checkbox=checkbox,
        sum_json=sum_json,
        sat_json=sat_json,
        PATH=script_path,
        logo=logo)

    with open(rendered_file_path, "w") as result_file:
        result_file.write(output_text)
        spipe.report_run_story(f"New report html: {rendered_file_path}")

    return True


def get_pipeline_json(spipe, samp):
    """ Get pipeline / run setting / version variables into json stucture

    Return dict
    """
    # Only get the number part of version (i.e. 'split-pipe v123' >--> v123)
    pipeline_version = spipe.get_version().split()[-1]
    chem = spipe.get_chemistry()
    kit_s, kit_n, _ = spipe.get_kit()
    # Format version footer string
    # Kit names get cleaned up
    if kit_s == 'WT':
        pass
    elif kit_s == 'WT_mini':
        kit_s = 'WT Mini'
    elif kit_s == 'WT_mega':
        kit_s = 'WT Mega'
    else:
        kit_s = f"(kit ? {kit_s})"
    #footer = f"Parse Biosciences - {kit_s} {chem}, Pipeline {pipeline_version}"
    footer = f"Parse Biosciences - Pipeline {pipeline_version}"

    # Important: Javascript booleans are lowercase
    is_targeted = 'true' if spipe.is_targeted() else 'false'
    is_comb = 'true' if spipe.is_combined() else 'false'
    is_tcr = 'true' if spipe.is_tcr() else 'false'
    is_focal = 'true' if spipe.is_focal_crispr(focal=True) else 'false'
    is_crispr = 'true' if spipe.is_focal_crispr(crispr=True) else 'false'
    is_meta_sample = 'true' if samp.is_meta() else 'false'
    have_parent = 'true' if spipe.have_parent() else 'false'

    pipeline_json = {
        'version_footer': footer,
        'pipeline_version': pipeline_version,
        'chemistry': chem,
        'kit': kit_s,
        'is_targeted': is_targeted,
        'is_comb': is_comb,
        'is_tcr': is_tcr,
        'is_focal': is_focal,
        'is_crispr': is_crispr,
        'is_meta_sample': is_meta_sample,
        'have_parent': have_parent,
    }
    return pipeline_json

                
### ----------------- Post process; Parent html merging ------------------

def post_proc_html_report(spipe, samp, ofname=''):
    """ Possibly post process new html report (writing a new one)
    
    Return status
    """
    new_lines = []
    
    if spipe.is_tcr():
        new_lines = post_proc_tcr_html(spipe, samp)
    elif spipe.is_focal_crispr():
        new_lines = post_proc_focal_html(spipe, samp)
    else:
        return True

    if not new_lines:
        spipe.set_problem(f"Post-process html merge for sample {samp.get_name()}")
        return False

    # Save 
    if not ofname:
        ofname = spipe.filepath('SF_ASUM_HTML', samp)
    with open(ofname, 'w') as OUTFILE:
        print('\n'.join(new_lines), file=OUTFILE)
        spipe.report_run_story2(f"Post processed html: {ofname}")
    
    return True


### ------------------- focal CRISPR specific -------------------

def post_proc_focal_html(spipe, samp):
    """ Post process new and parent html files together

    Return list of lines
    """
    spipe.report_run_story2(f"Post processing html (focal)")
    # Current html as list of lines
    cur_lines = get_html_report_lines(spipe, samp, parent=False)
    par_lines = get_html_report_lines(spipe, samp, parent=True)
        
    # Want parent header and page 1
    end_key = "block_end_page_Page1"
    p_st, p_en = line_list_block_coords(par_lines, enkey=end_key)
    # Want current html after header; Page 1 will become page 3
    start_key = "block_start_page_Page1"
    c_st, c_en = line_list_block_coords(cur_lines, stkey=start_key)

    # Useful coords should be pretty big; -1 if not found
    if (p_en < 1) or (c_st < 1):
        story = f"Failed to id html blocks; Curent {c_st} {c_en}, parent {p_st} {p_en}"
        spipe.set_problem(story)
        return False

    # Parent lines; Set focal variable true
    par_lines = par_lines[:p_en]
    if spipe.is_focal_crispr(focal=True):
        par_lines = simple_sub_list_lines(par_lines, 'is_focal = false', 'is_focal = true')
    else:
        par_lines = simple_sub_list_lines(par_lines, 'is_crispr = false', 'is_crispr = true')

    # Current lines
    cur_lines = cur_lines[c_st:]

    # Remove saturation plots; tscp and gene
    # Remove bc rank plot?
    no_bc_rank = True
    if no_bc_rank:
        start_key = "block_start_div_id_bc_rank_box"
    else:
        start_key = "block_start_div_id_tscp_sat_box"
    end_key = "block_end_div_id_gene_sat_box"
    cur_lines = line_list_extract_block(cur_lines, stkey=start_key, enkey=end_key, inverse=True)

    if no_bc_rank:
        start_key = "block_start_js_bc_rank_plot"
    else:
        start_key = "block_start_js_tscp_sat_plot"
    end_key = "block_end_js_gene_sat_plot"
    cur_lines = line_list_extract_block(cur_lines, stkey=start_key, enkey=end_key, inverse=True)

    # Page 1 becomes page 3
    cur_lines = simple_sub_list_lines(cur_lines, 'Page1', 'Page3')
    cur_lines = simple_sub_list_lines(cur_lines, 'pg1-plotly', 'pg3-plotly')

    new_lines = par_lines + cur_lines
        
    # Update nav blocks to include Page3
    new_lines = update_nav_list_lines(new_lines, 'Summary', 'Clustering', 'CRISPR')

    return new_lines


### ------------------- TCR specific -------------------

def generate_single_tcr_html_report(spipe, samp):
    """ Generate TCR html report for one sample
    
    Returns status; Outputs saved to files
    """
    
    # Stats; All stats dataframe
    stat_df = spipe.get_stats_data(samp)
    if spipe.have_parent():
        # Parent dir data
        par_dir = spipe.get_parent_info(key='path')
        par_stat_df = spipe.get_stats_data(samp, top_dir=par_dir)
        filtered = True
    else:
        par_stat_df = None
        filtered = False
    
    # Package jinja vars for pipeline
    pipeline_json = get_pipeline_json(spipe, samp)

    # statistics collection for report display
    spipe.report_run_story2(f"Collecting stats to report")
    sum_json = get_tcr_sum_stat_json(spipe, samp)

    spipe.report_run_story2(f"Collecting clonotype data (filtered {filtered})")
    clonotype_dict, clonotype_table_html = get_tcr_clonotype_table(spipe, samp, filtered=filtered)
    
    # ============ html / jinja ==========
    # output filename
    rendered_file_path = spipe.filepath('SF_ASUM_HTML', samp)
    # Input HTML templates for jinja2
    template_filename = '/templates/template_tcr.html.j2'
    script_path = spipe.get_pkg_path()
    template_file_path = os.path.join(script_path, template_filename)
           
    logo = get_logo_img(spipe)
    
    environment = jinja2.Environment(loader=jinja2.FileSystemLoader(searchpath=script_path))

    output_text = environment.get_template(template_filename).render(
        sum_json=sum_json,
        pipeline_json=pipeline_json,
        clonotype_dict=clonotype_dict,
        clonotype_table_html=clonotype_table_html,
        logo=logo,
        PATH=script_path)
    
    with open(rendered_file_path, "w") as result_file:
        result_file.write(output_text)
        spipe.report_run_story(f"New report html: {rendered_file_path}")

    return True


def post_proc_tcr_html(spipe, samp):
    """ Post process merging of new html and parent for TCR

    Returns list of lines
    """
    spipe.report_run_story2(f"Post processing html (TCR)")
    # Current html as list of lines
    cur_lines = get_html_report_lines(spipe, samp, parent=False)
    # Have parent 
    if spipe.have_parent():
        par_lines = get_html_report_lines(spipe, samp, parent=True)
        
        # Want all of parent html (e.g. header) up until end of page2
        end_key = "block_end_page_Page2"
        p_st, p_en = line_list_block_coords(par_lines, enkey=end_key)
        # Current only Page3 to end (no header)
        start_key = "block_start_page_Page3"
        c_st, c_en = line_list_block_coords(cur_lines, stkey=start_key)

        # Useful coords should be pretty big; -1 if not found
        if (p_en < 1) or (c_st < 1):
            story = f"Failed to id html blocks; Curent {c_st} {c_en}, parent {p_st} {p_en}"
            spipe.set_problem(story)
            return False
            
        par_lines = par_lines[:p_en]
        cur_lines = cur_lines[c_st:]
        new_lines = par_lines + cur_lines
        
        # Update nav blocks to include TCR Page3
        new_lines = update_nav_list_lines(new_lines, 'Summary', 'Clustering', 'TCR')
        
    # No parent
    else:
        # Update with added TCR only; Other links gone
        new_lines = update_nav_list_lines(cur_lines, '', '', 'TCR Summary')

    return new_lines


def get_tcr_sum_stat_json(spipe, samp, round_to=3):
    """ Get TCR summary stat collection
    
    Return json dict
    """
    stat_df = spipe.get_stats_data(samp)
    raw_dict = stat_df.iloc[:, 0].to_dict()
    
    stat_dict =  OrderedDict()
    stat_dict['Estimated Number of T Cells'] = raw_dict['tcr_number_of_cells']
    stat_dict['Mean Reads/Cell'] = raw_dict['tcr_mean_reads_per_cell']
    # stat_dict['Median VDJ Transcripts/Cell'] = raw_dict['tcr_median_VDJ_tscp_per_cell']
    
    # As fraction of all cells
    nc = raw_dict['tcr_number_of_cells']
    stat_dict['T Cells with Productive TRA'] = round(raw_dict['tcr_tcells_with_productive_TRA'] / nc, round_to)
    stat_dict['T Cells with Productive TRB'] = round(raw_dict['tcr_tcells_with_productive_TRB'] / nc, round_to)
    stat_dict['T Cells with Detected Productive Pair (TRA, TRB)'] = round(raw_dict['tcr_tcells_with_productive_pair'] / nc, round_to)

    # stat_dict['T Cells with Inferred Productive Pair (TRA, TRB)'] = round(raw_dict['tcr_tcells_with_productive_inferred_pair'] / nc, round_to)

    stat_dict['BC1 >Q30'] = raw_dict['bc1_Q30']
    stat_dict['BC2 >Q30'] = raw_dict['bc2_Q30']
    stat_dict['BC3 >Q30'] = raw_dict['bc3_Q30']
    stat_dict['cDNA >Q30'] = raw_dict['cDNA_Q30']    
    
    # Get list of kev-val dicts for json to javascript
    stat_list = utils.dict_to_kv_dict_list(stat_dict)

    sum_json = {
        'stat_list': stat_list,
        'cur_samp_name': samp.get_name(),
        'cur_samp_wells': samp.get_wells(),
        'cur_samp_nsublibs': samp.num_sublibs(),
    }
    
    return sum_json


def get_tcr_clonotype_table(spipe, samp, filtered=False):
    """ Get clonotype data
    
    """
    # File key depends on filtered or not
    fkey = 'SF_TCR_F_CLON_FREQ' if filtered else 'SF_TCR_UF_CLON_FREQ'

    clonotype_df = spipe.read_csv(fkey, samp, sep='\t', index_col=None)
    # Reduce decimals and 
    clonotype_df['frequency'] = clonotype_df['frequency'].round(4)
    clonotype_df['TRA'] = clonotype_df['TRA'].fillna('-')
    clonotype_df['TRB'] = clonotype_df['TRB'].fillna('-')

    clonotype_table = clonotype_df[['clonotype_id','TRA','TRB','count','frequency']]
    clonotype_table.columns = [['Clonotype ID','TRA','TRB','Count','Frequency']]
    clonotype_table_html = clonotype_table[:100].to_html(border=0,
                                                      index=False,
                                                      classes=['diff-table'])

    clonotype_table_html = clonotype_table_html.replace('dataframe','table')
    
    n_clonotype_to_plot = 10

    # Reverse order so highest clonotype is on top
    clonotype_df = clonotype_df[:n_clonotype_to_plot][::-1]

    # Reverse order so highest clonotype is on top
    clonotype_dict = {'clonotype_id':list(clonotype_df.clonotype_id.values),
                      'frequency':list(clonotype_df.frequency.values),
                     }

    hover_text = []
    for i in range(n_clonotype_to_plot):
        clonotype_text = str(clonotype_df.iloc[i].loc[['TRA','TRB','count']].to_dict())[1:-1]
        # Plotly uses breaks not \n
        clonotype_text = clonotype_text.replace(', ','<br />')
        # Remove excessive single quotes
        clonotype_text = clonotype_text.replace("'","")
        hover_text.append(clonotype_text)
    clonotype_dict['hover_text'] = hover_text
    
    return clonotype_dict, clonotype_table_html


### ------------------- Cluster analysis -------------------

def load_samp_analysis(spipe, samp, parent=False):
    """ Load data from analysis of one sample

    parent = flag to load from parent_dir

    Return dict with info and possibly andata
    """
    # If parent_dir (e.g. for focal bc)
    top_dir = None
    if parent:
        top_dir = spipe.get_parent_info(key='path')

    # Info file
    fname = spipe.filepath('SFR_ANA_PROC_DEF', samp, top_dir=top_dir)
    if utils.check_infile(fname, verb=False, toxic=False):
        pdict = utils.read_json(fname)
        info = pdict['analysis']
    else:
        info = {'status': None}

    dge_files = const.out_filepaths(spipe, samp, use_case=True, top_dir=top_dir)
    # anndata file; If status good and file exists
    if utils.check_infile(dge_files['anndata'], verb=False, toxic=False):
        adata = utils.load_parsebio_dge(dge_files['dir'], adata=True)
        spipe.report_run_story2(f"Loaded anndata {adata.shape} from {dge_files['dir']}")
        #adata.obs = cleanup_cell_df(adata.obs)
    else:
        adata = None
        spipe.report_run_story2(f"No analysis anndata found: {dge_files['anndata']}")

    return info, adata


def cleanup_cell_df(cell_df):
    """ Clean up missing values in cell dataframe

    Return (cleaned) dataframe
    """
    count_cols = [c for c in cell_df.columns if c.endswith("_count")]
    cell_df[count_cols] = cell_df[count_cols].fillna(0).astype(int)
    cell_df['sample'] = cell_df['sample'].fillna('all-well')
    return cell_df


def get_cell_sample_names(spipe, samp, adata, unique=False):
    """ Get list of sample names (from cells)

    unique = Flag to make unique (and sorted) list (e.g. for legend)

    Return list
    """
    # If focal, get from parent
    if spipe.is_focal_crispr():
        # Read cell dataframe
        par_dir = spipe.get_parent_info(key='path')
        fname = const.out_filepaths(spipe, samp, top_dir=par_dir)['cell']
        df = utils.read_csv(fname, index_col=0)
        slist = df['sample'].fillna('all-well')
    else:
        slist = adata.obs['sample']

    if unique:
        slist = sorted(slist.unique())
    else:
        slist = list(slist.values)
    return slist


def get_cell_cluster_names(spipe, samp, adata, ana_info, unique=False, as_str=True):
    """ Get list of cluster names

    unique = Flag to make unique (and sorted) list (e.g. for legend)
    as_str = Flag to make list values strings

    Return list
    """
    if spipe.is_focal_crispr():
        # Read cluster dataframe
        par_dir = spipe.get_parent_info(key='path')
        fname = spipe.filepath('SFR_CLUST_ASSIGN', samp, top_dir=par_dir)
        df = utils.read_csv(fname, index_col=0)
        clist = df['cluster']
    else:
        clust_alg = spipe.get_par_val('ana_cluster_alg', as_str=True)
        clist = adata.obs[clust_alg].astype(int)

    # If 1-based and min is zero, shift
    if spipe.get_par_val('ana_cluster_1base', as_bool=True) and (min(clist) == 0):
        clist += 1

    # Simple list of int; If unique, also sort
    if unique:
        clist = sorted(clist.unique())
    else:
        clist = clist.values
    # Cast as str?
    if as_str:
        clist = [str(c) for c in clist]
    return clist


def get_report_stats_kv_list(spipe, samp, stat_df, targeted=False, focal=False):
    """ Get (html) report stats with pretty print label and value ready for jinja

    Order of stats (name, val) in returned list = display order on page

    Return list of (key,val) stats in order for reporting on html
    """
    # Make dict from dataframe first col
    stat_dict = stat_df.iloc[:,0].to_dict()
    # List of key:values to be used
    stat_list = []

    if spipe.have_parent():
        parent_dir = spipe.get_parent_info(key='obj').get_name()
        #new_dict = {'Parent dir': parent_dir}
        #stat_list += utils.dict_to_kv_dict_list(new_dict)


    stat_list += get_cell_num_kv_list(spipe, stat_dict, targeted=targeted)

    if focal:
        stat_list += get_focal_tscp_gene_kv_list(spipe, stat_dict, targeted=targeted)
    else:
        stat_list += get_tscp_gene_kv_list(spipe, stat_dict, targeted=targeted)

    stat_list += get_reads_kv_list(spipe, stat_dict, targeted=targeted)
    if focal:
        stat_list += get_focal_kv_list(spipe, stat_dict, targeted=targeted)
    if targeted:
        stat_list += get_target_kv_list(spipe, stat_dict)
    stat_list += get_seq_kv_list(spipe, stat_dict, targeted=targeted)

    return stat_list


def get_cell_num_kv_list(spipe, stat_dict, targeted=False):
    """ Get the cell number parts of report into key:val dict list

    stat_dict = dict with all stats
    targeted = flag for targeted case

    Return list of k:v dicts
    """
    # Base key for number of cells
    xkey = 'targeted_' if targeted else ''
    b_key = f"{xkey}number_of_cells"

    # Total first
    new_dict = OrderedDict()
    new_dict['Estimated Number of Cells'] = stat_dict[b_key]

    # Only if multiple genomes
    if spipe.num_genomes() > 1:
        # Collect species specific keys; Multiplet is last
        k_list = []
        mult_key = ''
        for k in sorted(stat_dict.keys()):
            if k == b_key:
                continue
            if k.startswith('multiplet_'):
                mult_key = k
                continue
            if k.endswith(b_key):
                k_list.append(k)
        k_list.append(mult_key)
        # Final format
        for k in k_list:
            species = k.split('_')[0]
            new_dict[f"{species} Number of Cells Detected"] = stat_dict[k]

    stat_list = utils.dict_to_kv_dict_list(new_dict)
    return stat_list


def get_tscp_gene_kv_list(spipe, stat_dict, targeted=False):
    """ Get the transcript and gene parts of report into key:val dict list

    stat_dict = dict with all stats
    targeted = flag for targeted case

    Return list of k:v dicts
    """
    # Pretty print extra keyword
    p_xkey = 'Targeted ' if targeted else ''

    new_dict = OrderedDict()
    # Two pass, tscp first
    for k in sorted(stat_dict.keys()):
        if k.endswith('_median_tscp_per_cell'):
            # Only preface with species if more than one
            if spipe.num_genomes() > 1:
                species = k.split('_')[0]
                new_dict[f"{species} Median {p_xkey}Transcripts/Cell"] = stat_dict[k]
            else:
                new_dict[f"Median {p_xkey}Transcripts/Cell"] = stat_dict[k]

    for k in sorted(stat_dict.keys()):
        if k.endswith('_median_genes_per_cell'):
            if spipe.num_genomes() > 1:
                species = k.split('_')[0]
                new_dict[f"{species} Median {p_xkey}Genes/Cell"] = stat_dict[k]
            else:
                new_dict[f"Median {p_xkey}Genes/Cell"] = stat_dict[k]

    stat_list = utils.dict_to_kv_dict_list(new_dict)
    return stat_list


def get_focal_tscp_gene_kv_list(spipe, stat_dict, targeted=False):
    """ Focal median tscp per cell

    Return list of k:v dicts
    """
    xkey = 'targeted_' if targeted else ''

    species = spipe.get_genome_list()[0]
    stat_key = f"{species}_{xkey}median_tscp_per_cell"

    new_dict = OrderedDict()
    new_dict[f"Median Guide Transcripts/Cell"] = stat_dict[stat_key]

    stat_list = utils.dict_to_kv_dict_list(new_dict)
    return stat_list


def get_reads_kv_list(spipe, stat_dict, targeted=False):
    """ Get the read parts of report into key:val dict list

    stat_dict = dict with all stats
    targeted = flag for targeted case

    Return list of k:v dicts
    """
    # Extra key if targeted
    xkey = 'targeted_' if targeted else ''

    new_dict = OrderedDict()
    
    if spipe.is_focal_crispr(crispr=True): 
        new_dict['Guide Mean Reads/Cell'] = stat_dict['number_of_reads'] / stat_dict[f"{xkey}number_of_cells"]
        new_dict['Guide Number of Reads'] = stat_dict['number_of_reads']
    else:
        new_dict['Mean Reads/Cell'] = stat_dict['number_of_reads'] / stat_dict[f"{xkey}number_of_cells"]
        new_dict['Number of Reads'] = stat_dict['number_of_reads']

    stat_list = utils.dict_to_kv_dict_list(new_dict)
    return stat_list


def get_focal_kv_list(spipe, stat_dict, targeted=False):
    """ Get the focal barcoding parts of report into key:val dict list

    stat_dict = dict with all stats

    Return list of k:v dicts
    """
    new_dict = OrderedDict()
    xkey = 'targeted_' if targeted else ''

    n_cells = stat_dict[f"{xkey}number_of_cells"]
    n_any = n_cells - stat_dict['num_cells_with_0_focal_gene']
    #new_dict['Fraction Cells with Focal Genes'] = n_any / n_cells
    #new_dict['Usable Guide Fraction'] = n_any / n_cells
    new_dict['Fraction of Cells with Guides'] = n_any / n_cells

    new_dict['Number of Cells with 1 Guide'] = stat_dict['num_cells_with_1_focal_gene']
    new_dict['Number of Cells with >= 2 Guides'] = stat_dict['num_cells_with_2plus_focal_gene']

    stat_list = utils.dict_to_kv_dict_list(new_dict)
    return stat_list


def get_target_kv_list(spipe, stat_dict):
    """ Get the targeted parts of report into key:val dict list

    stat_dict = dict with all stats

    Return list of k:v dicts
    """
    new_dict = OrderedDict()
    new_dict['Fraction Reads on Target'] = stat_dict['targeted_read_fraction']
    new_dict['Targeted Number of Genes'] = stat_dict['target_number']
    new_dict['Fraction of Target Genes Found'] = stat_dict['targeted_gene_fraction']

    stat_list = utils.dict_to_kv_dict_list(new_dict)
    return stat_list


def get_seq_kv_list(spipe, stat_dict, targeted=False):
    """ Get the sequencing parts of report into key:val dict list

    stat_dict = dict with all stats

    Return list of k:v dicts
    """
    # Extra key and pretty keys if targeted or focal 
    xkey = 'targeted_' if targeted else ''
    p_xkey = 'Targeted ' if targeted else ''
    f_xkey = 'Guide ' if spipe.is_focal_crispr(crispr=True) else ''

    new_dict = OrderedDict()
    new_dict[f"{p_xkey}{f_xkey}Sequencing Saturation"] = stat_dict[f"{xkey}sequencing_saturation"]
    new_dict[f"{f_xkey}BC1 (RT) >Q30"] = stat_dict['bc1_Q30']
    new_dict[f"{f_xkey}BC2 >Q30"] = stat_dict['bc2_Q30']
    new_dict[f"{f_xkey}BC3 >Q30"] = stat_dict['bc3_Q30']
    new_dict[f"{f_xkey}cDNA >Q30"] = stat_dict['cDNA_Q30']

    stat_list = utils.dict_to_kv_dict_list(new_dict)
    return stat_list


def clear_plot_data():
    """ Close matplotlib stuff (should release memory)
    """
    plt.close()
    plt.clf()
    plt.cla()


def get_logo_img(spipe):
    """Get encoded image of company logo
    """
    # Convert company logo to bytecode
    logo_path = spipe.get_pkg_path() + '/templates/' + 'Parse_Logo_RGB_White.png'
    with open(logo_path, "rb") as image_file:
        logo = '"data:image/png;base64,' + base64.b64encode(image_file.read()).decode() + '"'
        return logo


def get_chk_img(spipe):
    """Get encoded image checkboxes for diff table
    """
    chk_path = spipe.get_pkg_path() + '/templates/' + 'checkbox.png'
    with open(chk_path, "rb") as image_file:
        chk = '"data:image/png;base64,' + base64.b64encode(image_file.read()).decode() + '"'
        return chk


def adjust_color(color, light=0.5, d_hue=0):
    """ Change lightness of given color
    """
    try:
        c = mc.cnames[color]
    except:
        c = color
    c = colorsys.rgb_to_hls(*mc.to_rgb(c))
    return colorsys.hls_to_rgb(c[0] + d_hue, max(0, min(1, light * c[1])), c[2])


def subsamp_plot_color(spec, sublib):
    """ Get color for sublibary

    spec = species counter var (0, 1, etc)
    sublib = sublibrary counter var (0, 1, 2, etc)
    """
    if (spec % 2) == 0:
        color = (0.3,0.75,0.95)
        light = 0.65
        d_light = 0.08
        d_hue = 0.05
    else:
        color = (0.95,0.5,0.1)
        light = 0.85
        d_light = 0.05
        d_hue = 0.02
    color = adjust_color(color, light=light+d_light*sublib, d_hue=d_hue*sublib)
    return color


def plot_plates(spipe, samp, targeted=False, focal=False):
    """ Handle plotting of all plate data heatmaps (cell and tscp for each bc round)

    Return json formatted list of heatmap values and layout for each plate
    """
    margin = {'l': 40,'t': 40, 'r': 40, 'b':40}
    xaxis = {'tickmode': 'array', 'tickvals': list(range(0,12)), 'ticktext': list(range(1,13))}
    colorscale = [[0, '#ffeded'],[1, '#d90000']]

    all_plates_json = []
    for rnd in [1, 2, 3]:
        for tscp in [True, False]:
            if tscp:
                p_type = 'tscp'
                if targeted:
                    p_title = f'Round {rnd} - Median Targeted Transcripts Per Well'
                    hovertemplate = '<b>%{y}%{x}</b> Targeted Transcripts: %{z} <extra></extra> '
                else:
                    if focal:
                        p_title = f'Round {rnd} - Median Guides Per Well'
                        hovertemplate = '<b>%{y}%{x}</b> Guides: %{z} <extra></extra> '
                    else:
                        p_title = f'Round {rnd} - Median Transcripts Per Well'
                        hovertemplate = '<b>%{y}%{x}</b> Transcripts: %{z} <extra></extra> '
            else:
                p_type = 'cell'
                p_title = f'Round {rnd} - Cells Per Well'
                hovertemplate = '<b>%{y}%{x}</b> Cells: %{z} <extra></extra> '

            # Plate rows depend on well count for round
            rows, cols = spipe.get_bc_plate_wells(rnd, as_list=True)
            # Rows are reversed for plotting, e.g. [D,C,B,A]
            rows = sorted(rows, reverse=True)

            # Valid bc / kit have rows = 1, 4, 8
            if len(rows) == 1:
                height = 100
                # Only single row heatmap; Need to extend colorbar, limit ticks
                # Heatmap colorbar parameters:
                #    https://plotly.com/python/reference/#heatmap-colorbar
                # To set colorbar starting at zero, need function on colorscale:
                #   https://community.plotly.com/t/heatmap-color-scale/46282
                #
                nticks = 3
                colorbar_len = 3.5
                yaxis_list = list(range(0, 1))
            elif len(rows) == 4:
                height = 170
                nticks = 4
                colorbar_len = 1
                yaxis_list = list(range(0, 4))
            elif len(rows) == 8:
                height = 245
                nticks = 4
                colorbar_len = 1
                yaxis_list = list(range(0, 8))
            else:
                story = f"plot_plates rnd={rnd} bogus plate row {len(rows)} col {len(cols)} dims"
                spipe.set_problem(story)
                return False

            # Get plate data; This also possibly plots figure
            well_z, min_z, max_z = plot_one_plate(spipe, samp, rnd, tscp=tscp)

            # Force zero for color scale?
            if spipe.get_par_val('rep_plate_min_zero', as_bool=True):
                min_z = 0

            # Package for plotly
            yaxis = {
                    'tickmode': 'array',
                    'tickvals': yaxis_list,
                    'ticktext': rows,
                    }
            well_json = [{
                    'type': 'heatmap',
                    'z': well_z,
                    'zmin': min_z,
                    'zmax': max_z,
                    'colorscale': colorscale,
                    'colorbar': {
                        'len': colorbar_len,
                        'nticks': nticks,
                        },
                    'hovertemplate': hovertemplate,
                    }]
            lyt_json = {
                    'height': height,
                    'width': 544,
                    'xaxis': xaxis,
                    'yaxis': yaxis,
                    'margin': margin,
                    'title': p_title,
                    }

            well_dict = {p_type + str(rnd) : well_json}
            well_lyt = {'lyt_' + p_type + str(rnd): lyt_json}
            all_plates_json.extend([well_dict, well_lyt])

    return all_plates_json


def plot_one_plate(spipe, samp, rnd, tscp=False):
    """ Plot transcript / cell counts per well (i.e. plates)

    rnd = plate round (1, 2, 3)
    tscp = flag for transcripts; else cells

    return tuple ([list of well values], min, max)
    """
    if tscp:
        title = f"Round {rnd} - median transcripts per well"
        # file name keys like 'SFR_TSCP_R3W'
        fkey = f"SFR_TSCP_R{rnd}W"
        figkey = f"SFR_FIG_TSCP_R{rnd}W"
    else:
        title = f"Round {rnd} - cells per well"
        # file name keys like 'SFR_CELL_R3W'
        fkey = f"SFR_CELL_R{rnd}W"
        figkey = f"SFR_FIG_CELL_R{rnd}W"

    # Wells saved as 1-based; Need to shift to 0-based for reshape
    plate_df = spipe.read_csv(fkey, samp=samp)

    # List of rows and columns (both lists as strings)
    rows, cols = spipe.get_bc_plate_wells(rnd, as_list=True)

    if len(rows) == 1:
        plot_df = plate_df['count'].values.reshape(1, len(cols))
        yticks = range(0,1)
        yticklabels = rows
    elif len(rows) == 4:
        plot_df = plate_df['count'].values.reshape(4, len(cols))
        yticks = range(0,4)
        yticklabels = rows
    elif len(rows) == 8:
        plot_df = plate_df['count'].values.reshape(8, len(cols))
        yticks = range(0,8)
        yticklabels = rows
    else:
        story = f"plot_one_plate rnd={rnd} bogus plate row {len(rows)} col {len(cols)} dims"
        spipe.set_problem(story)
        return False

    xticks = range(0, len(cols))
    xticklabels = cols

    # Save figure to file?
    if spipe.get_par_val('rep_save_figs', as_bool=True):
        fig = plt.figure(figsize=(6,5), dpi=200)
        ax = fig.add_subplot(111)
        cm = plt.imshow(plot_df, cmap=plt.cm.Reds, vmin=0)
        ax.set_xticks(xticks)
        ax.set_xticklabels(xticklabels)
        ax.set_yticks(yticks)
        ax.set_yticklabels(yticklabels)
        ax.set_title(title, fontsize=14)
        fig.colorbar(cm, pad=0.02, aspect=10, shrink=0.7)
        fname = spipe.filepath(figkey, samp)
        fig.savefig(fname, format='png', bbox_inches='tight', dpi=200)

    clear_plot_data()

    # Data for plotly / json
    plot_mat = []
    for row in range(len(plot_df)):
        plot_mat.append(list(plot_df[row]))
    # Need to reverse rows to display plates correctly
    plot_mat.reverse()

    return (plot_mat, plot_df.min(), plot_df.max())


def plot_gt_subsamp(spipe, samp, tscp=False, targeted=False):
    """ Plot subsample curves of gene / transcript count with reads

    tscp = flag for transcripts; else cells
    targeted = flag for target enrichment

    return dictionary with coordinates for plotly
    """
    # Extra keys and word part of keys if targeted
    xkey = p_xkey = ''
    if targeted:
        xkey = 'targeted_'
        p_xkey = 'Targeted '

    # Transcript or cell
    if tscp:
        fkey = 'SFR_SS_TSCP_CT'
        xlab = "Sequencing Reads per Cell"
        ylab = f"Median {p_xkey}Transcripts per Cell"
        title = f"{p_xkey}Transcripts per Cell"
        figkey = 'SFR_FIG_SS_TSCP'
    else:
        fkey = 'SFR_SS_GENE_CT'
        xlab = "Sequencing Reads per Cell"
        ylab = f"Median {p_xkey}Genes per Cell"
        title = f"{p_xkey}Genes per Cell"
        figkey = 'SFR_FIG_SS_GENE'
    ss_df = spipe.read_csv(fkey, samp=samp)

    # Shouldn't ever have more than two species
    colors = [[0.00, 0.25, 0.8], [0.75, 0.25, 0.0], ['#2CA02C']]

    fig = plt.figure(figsize=(6,5), dpi=200)
    ax = fig.add_subplot(111)

    species = spipe.get_genome_list()
    #is_comb = spipe.is_combined()
    is_comb = samp.is_combined()
    # Combine any sublibraries into single lines
    for i, spec in enumerate(species):
        if is_comb:
            s_cols = [x for x in ss_df.columns if x.startswith(f"{spec}__")]
        else:
            s_cols = [x for x in ss_df.columns if x.startswith(spec)]
        # Each sublib (maybe just one)
        for j,col in enumerate(s_cols):
            lab = f"{spec}_{j+1}" if is_comb else spec
            color = subsamp_plot_color(i, j)
            spec_df = ss_df[col].dropna()
            spec_df.plot(label=lab, ax=ax, marker='o', color=color)

    # Save figure to file
    if spipe.get_par_val('rep_save_figs', as_bool=True):
        ax.legend()
        ax.set_ylabel(ylab)
        ax.set_xlabel(xlab)
        ax.set_title(title, size=16)
        fname = spipe.filepath(figkey, samp)
        fig.savefig(fname, format='png', bbox_inches='tight', dpi=200)

    clear_plot_data()

    subsamp_json = []
    for column in ss_df:
        tmp = ss_df[column].dropna(axis=0)
        subsamp_json.append({'name': tmp.name, 'mode': 'lines',
        'x': tmp.index.to_list(), 'y': tmp.values.tolist()})

    return subsamp_json


def plot_bc_rank(spipe, samp, stat_df, targeted=False, par_stat_df=None):
    """ Plot tscp-per-barcode, cell cutoff, tscp-rank "knee plot"

    stat_df = dataframe with stats (i.e. analysis_summary.csv; Maybe combined)

    return json object for plotly
    """
    # Make dict from dataframe first col
    stat_dict = stat_df.iloc[:,0].to_dict()

    focal = spipe.is_focal_crispr()
    if focal:
        par_stat_dict = par_stat_df.iloc[:,0].to_dict()
        # Parent path to dataframe
        par_dir = spipe.get_parent_info(key='path')
        par_tscp_counts = spipe.read_csv('SFR_TSCP_CT', samp=samp, top_dir=par_dir)

    # Get series with counts, number of these over cutoffs
    tscp_counts = spipe.read_csv('SFR_TSCP_CT', samp=samp)

    # Focal uses parent info
    if focal:
        cut_min = 1
        #cut_max = int(tscp_counts.max())
        cut_max = int(max(tscp_counts.iloc[0]))

        key = 'number_of_cells'
        if key not in par_stat_dict:
            xkey = 'targeted_' if targeted else ''
            key = f"{xkey}number_of_cells"

        print("focal key", key)
        n_cells = int(par_stat_dict[key])

    else:
        # Cutoff; Maybe one or combined
        cut_list = list(stat_df.loc['cell_tscp_cutoff'].values)
        cut_tscp = cut_list[0]
        cut_min = min(cut_list)
        cut_max = max(cut_list)

        # Number of cells; Previously determined (not via thresh cutoff)
        xkey = 'targeted_' if targeted else ''
        #row = f"{xkey}cell_number_estimate"
        row = f"{xkey}number_of_cells"
        print("non-focal row", row)
        #n_cells = int(stat_df.loc[col, 'value'])
        n_cells = int(list(stat_df.loc[row].values)[0])

    counts_df = tscp_counts['count'].sort_values(ascending=False)
    n_top = len(counts_df[counts_df >= cut_max])
    n_bot = len(counts_df[counts_df >= cut_min])

    print("plot_bc_rank n_top, n_bot", n_top, n_bot)

    # plot config
    fig = plt.figure(figsize=(5,5), dpi=200)
    ax = fig.add_subplot(111)

    # Full set (all counts_df) as grey
    ax.plot(range(len(counts_df)),
            counts_df.values,
            color='lightgray',
            linewidth=2)
    # If more than one (i.e. combined) thresh, middle as light green dots
    if n_top != n_bot:
        ax.plot(range(n_bot),
                counts_df.values[:n_bot],
                color='#A0D3AA',
                linewidth=0,marker='.')
    # Passing cell set as green dots
    ax.plot(range(n_top),
            counts_df.values[:n_top],
            color='g',
            linewidth=0,marker='.')

    ax.set_xscale('log')
    ax.set_yscale('log')
    _ = ax.set_xlabel('# Barcodes (logscale)')
    if focal:
        _ = ax.set_ylabel('# Guides (logscale)')
    else:
        _ = ax.set_ylabel('# Transcripts (logscale)')

    # Annotation text
    cell_str = utils.report_num_str(n_cells)
    if cut_min != cut_max:
        tscp_str = f"({utils.report_num_str(cut_min)} - {utils.report_num_str(cut_max)})"
    else:
        tscp_str = f"{utils.report_num_str(cut_min)}"
    median_tscp = utils.report_num_str(counts_df[:n_cells].median())
    tx_str = f" n_cells: {cell_str}\n tscp_cutoff: {tscp_str}\n median_tscp: {median_tscp}"
    ax.text(1, 10, tx_str)

    ax.set_title('Identified Cells', size=15)

    # Save figure to file
    if spipe.get_par_val('rep_save_figs', as_bool=True):
        fname = spipe.filepath('SFR_FIG_CELL_CUTOFF', samp)
        fig.savefig(fname, format='png', bbox_inches='tight', dpi=200)

    clear_plot_data()

    # Calc and collect values for plotly
    bc_x_raw = list(range(len(counts_df)))
    bc_y_raw = list(counts_df.values)

    # Subsample values in bc rank plot
    max_x = len(bc_x_raw)
    num_points = 5000
    x_step = max_x**(1/num_points)
    x_int = np.arange(num_points)
    bc_sub_x = np.unique((x_step**x_int).astype(int)).tolist()
    bc_sub_y = [bc_y_raw[i] for i in bc_sub_x]

    print(f"BBB lens {len(bc_x_raw)} {len(bc_y_raw)}")

    if n_bot >= len(bc_y_raw):
        print(f"Hacking plot bc_y_raw... (n_bot {n_bot} to {len(bc_y_raw) - 1})")
        n_bot = len(bc_y_raw) - 1

    if n_top >= len(bc_y_raw):
        print(f"Hacking plot bc_y_raw... (n_top {n_top} to {len(bc_y_raw) - 1})")
        n_top = len(bc_y_raw) - 1

    # Insert n_top and n_bot back into bc list
    bc_sub_x.extend([n_top, n_bot])
    bc_sub_x.sort()

    print(f"BBB top {n_top} bot {n_bot}")

    bc_sub_y.extend([bc_y_raw[n_top], bc_y_raw[n_bot]])
    bc_sub_y.sort(reverse=True)

    # Convert to string for jinja (can't load int)
    bc_rank_x = list(map(str, bc_sub_x))
    bc_rank_y = list(map(str, bc_sub_y))

    bc_rank_json = [bc_rank_x, bc_rank_y, str(n_top), str(n_bot)]

    return bc_rank_json


def render_clus_gene_tab(spipe, samp):
    """ Generate table with contents of table for per-cluster gene info

    Returns nothing; Output saved to (temp) file
    """
    num_genomes = spipe.num_genomes()

    focal = spipe.is_focal_crispr()
    top_dir = None
    if focal:
        # Parent path to dataframe
        top_dir = spipe.get_parent_info(key='path')

    # Load data table
    # Default is to use first col as index, but want 'cluster' as column
    diff_exp_df = spipe.read_csv('SFR_CLUST_DIFF_EXP', samp=samp, index_col=None, top_dir=top_dir)

    # Replace simple gene_name with url
    url_list = []
    # Interows yields idx, values
    for _, row in diff_exp_df.iterrows():
        gene_name, gene_id, genome = row.loc[['gene_name','gene_id','genome']]
        # Name to report with
        if gene_name:
            rep_name = gene_name
        else:
            rep_name = gene_id
        # If multi-genome, append that
        if num_genomes > 1:
            rep_name = rep_name + '_' + genome

        # Attempt to get genome-appropriate url for gene
        url = spipe.get_gene_url(genome, gene_id)
        if url:
            url_list.append(f"<a href=\"{url}\" target=\"_blank\">{rep_name}</a>")
        else:
            url_list.append(f"{rep_name}")

    diff_exp_df.loc[:,'gene_name'] = pd.Series(url_list)

    """ Finalize things for (temp) per-clust gene enrichment html report
    """
    # Number formatting for score, log2_fc, pct1, pct2, and pval_adj
    diff_exp_df['score'] = diff_exp_df['score'].round(1)
    diff_exp_df['log2_FC'] = diff_exp_df['log2_FC'].round(1)
    diff_exp_df['pct1'] = diff_exp_df['pct1'].apply(lambda x: round(x*100, 1))
    diff_exp_df['pct2'] = diff_exp_df['pct2'].apply(lambda x: round(x*100, 1))
    diff_exp_df['pval_adj'] = diff_exp_df['pval_adj'].apply(lambda x: f"{x:.1E}")

    # Subset of cols that will be in html
    show_cols = "cluster,gene_name,score,log2_FC,pval_adj".split(",")
    diff_exp_df = diff_exp_df[show_cols]

    # Render and write html table to file
    html_out = diff_exp_df.to_html(classes='table', table_id='diff-table',
        render_links=True, escape=False, col_space=1, index=False)
    html_out = html_out.replace('dataframe table', 'table')

    diff_table_path = spipe.filepath('TMP_DIFF_TAB_HTML', samp)

    # Hover over dialog for html table
    tip_rep = f'<th style="min-width: 1px;" data-sortable="true" \
         data-toggle="tooltip" data-container="body" data-placement="bottom" title='

    pct1_th_old = f'<th style="min-width: 1px;">pct1'
    pct1_tip = f'"Percentage of cells expressing gene in cluster."'
    pct1_th_new = tip_rep + pct1_tip + f'>Pct1'

    pct2_th_old = f'<th style="min-width: 1px;">pct2'
    pct2_tip = f'"Percentage of cells expressing gene in opposing clusters."'
    pct2_th_new = tip_rep + pct2_tip + f'>Pct2'

    leiden_th_old = f'<th style="min-width: 1px;">cluster'
    leiden_tip = f'"Clusters generated from the Leiden algorithm."'
    leiden_th_new = tip_rep + leiden_tip + f'>Cluster'

    gene_th_old = f'<th style="min-width: 1px;">gene_name'
    gene_tip = f'"Gene symbol taken from annotation."'
    gene_th_new = tip_rep + gene_tip + f'>Gene name'

    score_th_old = f'<th style="min-width: 1px;">score'
    score_tip = f'"This metric selects genes with the highest log fold change \
        which are also expressed in the greatest number of cells within a cluster. \
        Formula: Log2 FC x (percentage of cells expressing gene in cluster of interest / \
            percentage of cells expressing gene all other clusters)"'
    score_th_new = tip_rep + score_tip + f'>Score'

    # Non-scanpy pvalue calc
    # https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.ranksums.html
    # scipy.stats.ranksums(x, y)[source]
    #   Compute the Wilcoxon rank-sum statistic for two samples.

    pval_adj_th_old = f'<th style="min-width: 1px;">pval_adj'
    pval_adj_tip = f'"p-value calculated from Wilcoxon rank-sum test"'
    pval_adj_th_new = tip_rep + pval_adj_tip + f'>Pval adj'

    log_FC_th_old = f'<th style="min-width: 1px;">log2_FC'
    log_FC_tip = f'"Log2 fold change between gene in cluster of \
        interest vs. all other clusters."'
    log_FC_th_new = tip_rep + log_FC_tip + f'>Log2 FC'

    html_out = html_out.replace(pct1_th_old, pct1_th_new)
    html_out = html_out.replace(pct2_th_old, pct2_th_new)
    html_out = html_out.replace(gene_th_old, gene_th_new)
    html_out = html_out.replace(log_FC_th_old, log_FC_th_new)
    html_out = html_out.replace(leiden_th_old, leiden_th_new)
    html_out = html_out.replace(score_th_old, score_th_new)
    html_out = html_out.replace(pval_adj_th_old, pval_adj_th_new)
    html_out = html_out.replace(log_FC_th_old, log_FC_th_new)

    # Add parameter for bootstrap 5 table sorting
    # html_out = html_out.replace('<table', '<table data-custom-sort="customSort"')

    diff_table_path = spipe.filepath('TMP_DIFF_TAB_HTML', samp)
    html_write = open(diff_table_path, 'w')
    html_write.write(html_out)
    html_write.close()


def plot_barnyard(spipe, samp):
    """ Plot the two-species barnyard scatter plot

    Returns nothing (barnyard not in html report)
    """
    if spipe.is_focal_crispr():
        print("Barnyard not yet for focal / crispr")
        return

    # Cell tscp count per species
    cell_data = spipe.read_csv('SFR_SPEC_TSCP_CT', samp)
    genomes = list(cell_data.columns)
    assert len(genomes) > 1, f"Barnyard needs > 1 genomes; {len(genomes)}"
    counts1 = cell_data.iloc[:,0]
    counts2 = cell_data.iloc[:,1]

    # Separate cells by species or mixed if not pure enough
    spurity = spipe.get_par_val('dge_species_purity_thresh', as_float=True)
    pfactor = spurity / (1 - spurity)
    cell_type1 = counts1 > (counts2 * pfactor)
    cell_type2 = counts2 > (counts1 * pfactor)
    mixed_cells = ~(cell_type1 | cell_type2)

    # Plotting per se
    fig = plt.figure(figsize=(5, 5))
    ax = fig.add_subplot(111)
    colors = [(0.894, 0.101, 0.109),
              (0.215, 0.494, 0.721),
              'gray']
    s = 5
    fsize=12
    plt.scatter(counts1[mixed_cells], counts2[mixed_cells], color=colors[2], s=s, label=None)
    plt.scatter(counts1[cell_type2], counts2[cell_type2], color=colors[0], s=s, alpha=1, label=None)
    plt.scatter(counts1[cell_type1], counts2[cell_type1], color=colors[1], s=s, label=None)
    plt.scatter([],[], color=colors[0], s=10,
            label='%d %s (%0.1f'%(sum(cell_type2),genomes[1],100*float(sum(cell_type2))/len(cell_type2))+'%)')
    plt.scatter([],[], color=colors[1], s=10,
            label='%d %s (%0.1f'%(sum(cell_type1),genomes[0],100*float(sum(cell_type1))/len(cell_type1))+'%)')
    plt.scatter([],[], color=colors[2], s=10,
            label='%d Mixed (%0.1f'%(sum(mixed_cells),100*float(sum(mixed_cells))/len(mixed_cells))+'%)')

    lim = int((counts1+counts2).max()*1.1)
    if lim > 30000:
        tickstep=5000
    else:
        tickstep=2000
    ax.set_xticks(np.arange(0,lim,tickstep))
    ax.set_yticks(np.arange(0,lim,tickstep))
    ax.set_xticklabels(np.arange(0,lim,tickstep),rotation=90)
    ax.axis([-int(lim/30.),lim,-int(lim/30.),lim])
    ax.set_xlabel('%s Transcript Counts' %genomes[0],fontsize=fsize)
    ax.set_ylabel('%s Transcript Counts' %genomes[1],fontsize=fsize)
    ax.tick_params(labelsize=fsize)
    ax.yaxis.tick_left()
    ax.xaxis.tick_bottom()
    ax.legend(fontsize=fsize-1, handletextpad=0.025, frameon=False)
    ax.get_xaxis().set_major_formatter(
        tickr.FuncFormatter(lambda x, p: format(int(x), ',')))
    ax.get_yaxis().set_major_formatter(
        tickr.FuncFormatter(lambda x, p: format(int(x), ',')))
    ax.set_title('Barnyard', size=18)

    # Save figure to file
    fname = spipe.filepath('SFR_FIG_BARNYARD', samp)
    fig.savefig(fname, format='png', bbox_inches='tight', dpi=200)

    clear_plot_data()


##### -------- HTML parsing for reuse; UMAP gex bloc focal_bc, TCR --------

def line_list_block_coords(lines, stkey=None, enkey=None, inclusive=True):
    """ Search list of lines for block between start, end keys

    Return tuple(start, end)
    """
    bst = ben = -1
    for i, line in enumerate(lines):
        if stkey and (bst < 0) and stkey in line:
            bst = i
            if not inclusive:
                bst += 1
        if enkey and (ben < 0) and enkey in line:
            ben = i
            if inclusive:
                ben += 1
    return (bst, ben)


def line_list_extract_block(lines, stkey=None, enkey=None, inverse=False):
    """ Search list of lines for block between start, end keys

    inverse = flag go invert what's saved; If inverse=True, block removed

    Return list of lines
    """
    new_lines = []
    bst, ben = line_list_block_coords(lines, stkey=stkey, enkey=enkey)
    if (bst >= 0) and (ben >= 0):
        if inverse:
            new_lines = lines[:bst] + lines[ben:]
        else:
            new_lines = lines[bst:ben]
    return new_lines


def get_html_report_lines(spipe, samp, parent=False, verb=True):
    """
    """
    top_dir = None
    if parent:
        top_dir = spipe.get_parent_info(key='path')
    fname = spipe.filepath('SF_ASUM_HTML', samp, top_dir=top_dir)
    lines = utils.lines_from_fname(fname, comment=None)
    if verb:
        spipe.report_run_story2(f"Loaded {len(lines)} lines from {fname}")
    return lines


def get_html_report_gex_block(spipe, samp, parent=True):
    """
    """
    lines = get_html_report_lines(spipe, samp, parent=parent)

    start_key = 'UMAP_color_map_start'
    end_key = 'UMAP_color_map_end'
    st,en = line_list_block_coords(lines, stkey=start_key, enkey=end_key)
    if (st >= 0) and (en >= 0):
        raw_lines = lines[st:en]
        # Extract only data lines; These start with ' and have ':['
        lines = []
        for one_line in raw_lines:
            if (one_line[0] == "'") and ("':[" in one_line):
                lines.append(one_line)
    else:
        lines = []
    return lines


def update_nav_list_lines(line_list, page1, page2, page3):
    """ Modify nav bar list in lines from html
    
    page1 = text for page 1 link
    page2 = text for page 2 link
    page3 = text for page 3 link
    
    Return updated line list
    """
    # Search key words
    start_key = 'block_start_list_navbar'
    end_key = 'block_end_list_navbar'
    new_lines = []

    in_block = False
    for line in line_list:
        # Block start marker
        if start_key in line:
            in_block = True
            new_lines.append(line)
            continue
            
        # Block end
        if end_key in line:
            in_block = False

            # Now add what's real
            if page1:
                new_lines.append(one_nav_link_line(1, page1))
            if page2:
                new_lines.append(one_nav_link_line(2, page2))
            if page3:
                new_lines.append(one_nav_link_line(3, page3))

            # Finish with end marker
            new_lines.append(line)
            continue

        # Ignore actual lines in block
        if in_block:
            continue
        
        new_lines.append(line)

    return new_lines


def one_nav_link_line(page_num, new_txt):
    """ Get single nav link line
    
    Lines need to look like this:

        <li><a href="#" onclick="return show_page('Page1');">Summary</a></li>

    Return string
    """
    new_line = '<li><a href="#" onclick="return show_page('
    new_line += f"'Page{page_num}');"
    new_line += '">'
    new_line += f"{new_txt}</a></li>"

    return new_line


def simple_sub_list_lines(line_list, s_pat, r_pat):
    """ Apply simple substitution of patterns in list of lines

    Return list of lines
    """
    new_lines = []
    for line in line_list:
        new_lines.append(line.replace(s_pat, r_pat))
    return new_lines


def plot_umap(spipe, samp, adata, ana_info, verb=True, targeted=False):
    """ Plot UMAP clusters

    return json object for plotly
    """
    focal = spipe.is_focal_crispr()

    # Hardcoded parameters
    round_to = 2

    if focal:
        pdir = spipe.get_parent_info(key='path')
        umap_df = spipe.read_csv('SFR_CLUST_UMAP', samp, top_dir=pdir)
        umap_df.rename({'umap_X': 'x', 'umap_Y': 'y'}, axis=1, inplace=True)
        prefix = 'FocalBC_'

    else:
        # Collect info to create plots; new dataframe mixing UMAP and cell values
        umap_df = pd.DataFrame(adata.obsm['X_umap'], index=adata.obs.index, columns=['x', 'y'])
        prefix = ''

    clust_alg = ana_info['cluster_alg']

    # Extra key(word) if targeted
    xkey = 'targeted_' if targeted else ''

    plot_umap_static(spipe, samp, adata, ana_info, verb=verb, targeted=targeted)

    # ============ Encoded strings for html ==========
    if focal:
        # gex data strings from parent html
        lines = get_html_report_gex_block(spipe, samp, parent=True)
        # Includes markers and open/close paren in first/last lines
        story = f"Recycling {len(lines)} gex data lines from parent html"
        spipe.report_run_story2(story)

        # Zero out non-call 
        mtx = handle_mtx_zero_thresh(spipe, samp, adata.X)
        cg_mat = csc_matrix(mtx)
        gene_names = adata.var.index.values
        tlines = get_umap_gex_lines(spipe, samp, gene_names, cg_mat, 'FocalBC_')
        story = f"Adding {len(tlines)} focal barcode lines"
        spipe.report_run_story2(story)
        lines += tlines

    else:
        # Convert scipy csr (compressed sparse row) to csc (c s col) matrix
        # Speeds up column slicing
        cg_mat = csc_matrix(adata.layers['norm10k'])
        gene_names = adata.var.index.values
        lines = get_umap_gex_lines(spipe, samp, gene_names, cg_mat)

    tlines = get_umap_count_lines(spipe, samp, adata, targeted=targeted, round_to=round_to, prefix=prefix)
    lines += tlines

    # If target enrichment, add this
    if targeted:
        if focal:
            print("target enrichment UMAP not yet for focal / crispr")
        else:
            tlines = get_umap_targeted_lines(spipe, samp, umap_df, round_to=round_to, verb=verb)
            lines += tlines

    # X and Y coords
    # To string; Only rle encoding; no lzw and no value-to-char mapping
    x_vals = umap_df['x'].values.round(round_to)
    y_vals = umap_df['y'].values.round(round_to)
    x_str = num_list_pack_str_rle(x_vals)
    y_str = num_list_pack_str_rle(y_vals)

    # Final string forms
    cmap_str = "{\n" + "\n".join(lines) + "\n}"
    x_str = f"'{x_str}'"
    y_str = f"'{y_str}'"
    samp_list = get_cell_sample_names(spipe, samp, adata, unique=False)
    clust_list = get_cell_cluster_names(spipe, samp, adata, ana_info, unique=False)

    umap_json = {'umap_cdata': cmap_str, 
                'umap_x': x_str, 
                'umap_y': y_str, 
                'umap_samples': samp_list, 
                'umap_clusters': clust_list}
    return umap_json


def handle_mtx_zero_thresh(spipe, samp, mtx):
    """ Handle possible zero-masking (sparse) matrix values less than thresh

    Return (sparse) matrix
    """
    if spipe.get_par_val('rep_umap_fb_zero_nc', as_bool=True):
        df = spipe.read_csv('SFR_TSCP_CUTOFF', samp=samp)
        thresh = int(float(df.loc['cell_tscp_cutoff','value']))
        spipe.report_run_story2(f"Masking DGE elements < thresh {thresh}")
        # This changes the matrix; < thresh elements get eliminated
        mtx = utils.mtx_zero_less_than(mtx, thresh)
    return mtx


def get_umap_gex_lines(spipe, samp, gene_names, cg_mat, prefix=''):

    print(">> get_umap_gex_lines GGG", prefix)

    # Processing takes a while; Updating stuff
    n_genes = len(gene_names)
    update_freq = n_genes / 10
    if n_genes < 2000:
        update_freq = update_freq * 2
    update_freq = int(update_freq)

    n_cells = cg_mat.shape[0]

    spipe.report_run_story2(f"Packaging gene expression data for plots ({n_genes} genes, {n_cells} cells)")
    nthreads = spipe.get_par_val('nthreads', as_int=True)
    nthreads = min(4, nthreads)

    # Each column = each gene
    if nthreads > 1:
        spipe.report_run_story2(f"Using {nthreads} threads for multiprocessing")
        #pool = mp.Pool(nthreads, maxtasksperchild=1000)
        pool = mp.Pool(nthreads)
        lines = pool.starmap_async(one_umap_gene_str,
                                   [(cg_mat, gene_names, g, update_freq, prefix) for g in range(len(gene_names))],
                                  chunksize=None).get()
        # clean up
        pool.close()
        pool.join()

    else:
        spipe.report_run_story2(f"Not multiprocessing")
        lines = []
        for i in range(len(gene_names)):
            num_str = one_umap_gene_str(cg_mat, gene_names, i, update_freq, prefix)
            lines.append(num_str)

    print("<< get_umap_gex_lines", len(lines))
    return lines


def get_umap_count_lines(spipe, samp, adata, targeted=False, round_to=2, prefix=''):
    """
    """
    print(">> get_umap_count_lines", prefix)
    lines = []

    # Get counts of genes, tscp, mapped reads and tscp/genes
    xkey = 'targeted_' if targeted else ''

    # read_count
    counts = np.log10(adata.obs[f"{xkey}mread_count"].values + 1).round(round_to)
    num_str = num_list_pack_str_rle(counts)
    lines.append(f"'{prefix}read_count':['Count', 'Log10', 'raw','{num_str}'],")

    if spipe.is_focal_crispr():
        # For focal, 'tscp_count' is gRNA_count
        counts = np.log2(adata.obs[f"{xkey}tscp_count"].values + 1).round(round_to)
        num_str = num_list_pack_str_rle(counts)
        lines.append(f"'{prefix}gRNA_count':['Count', 'Log2', 'raw','{num_str}'],")

        # For focal, 'gene_count' is number of dif gRNA
        counts = np.log2(adata.obs[f"{xkey}gene_count"].values + 1).round(round_to)
        num_str = num_list_pack_str_rle(counts)
        lines.append(f"'{prefix}ndg_count':['Count', 'Log2', 'raw','{num_str}'],")

    else:
        counts = np.log10(adata.obs[f"{xkey}tscp_count"].values + 1).round(round_to)
        num_str = num_list_pack_str_rle(counts)
        lines.append(f"'{prefix}tscp_count':['Count', 'Log10', 'raw','{num_str}'],")

        # gene_count
        counts = np.log10(adata.obs[f"{xkey}gene_count"].values + 1).round(round_to)
        num_str = num_list_pack_str_rle(counts)
        lines.append(f"'{prefix}gene_count':['Count', 'Log10', 'raw','{num_str}'],")

    print("<< get_umap_count_lines", len(lines))
    return lines


def get_umap_targeted_lines(spipe, samp, umap_df, round_to=2, verb=True, prefix=''):
    """ Get umap target enrichment data lines for plotting

    Return list of encoded strings (i.e. UMAP fields)
    """
    print(">> get_umap_targeted_lines", prefix)

    fracs_df = spipe.read_csv('SFR_ENRICHMENT', samp=samp, index_col=0, verb=verb)
    # Get (ordrerd) possible subset of fraction data (umap may be downwampled)
    fracs_df = fracs_df.loc[umap_df.index]

    lines = []
    # For each column
    for col in fracs_df.columns:
        vals = fracs_df[col].values.round(round_to)
        num_str = num_list_pack_str_rle(vals)
        lines.append(f"'{prefix}{col}':['Fraction', '', 'raw','{num_str}'],")

    print("<< get_umap_targeted_lines", len(lines))
    return lines


def one_umap_gene_str(cg_mat, gene_names, col, update_freq, prefix, round_to=2):
    """ Process one gene's worth of data for umap plot

    cg_mat = sparse matrix with normalized DGE values
    gene_names = list of gene names (i.e. matrix columns)
    col = which column to process
    update_freq = feedback print control; Zero makes no prints

    Return str
    """
    if update_freq and ((col+1) % update_freq) == 0:
        p_str = utils.report_percent_str(col, len(gene_names))
        print(f" packaged {col}\t{p_str}")
        sys.stdout.flush()

    # Cell gene counts; Slice of sparse matrix >--> array
    r_slice = np.array(np.squeeze(cg_mat.getcol(col).toarray()))
    # Scale log2
    c_slice = np.log2(r_slice + 1)
    # Round and cast to strings in array (faster than raw python)
    s_slice = np.ceil(c_slice).astype(int).astype(str)
    # Encoded data string
    num_str = int_list_pack_str_lzw(s_slice)

    name = f"{prefix}{gene_names[col]}"
    return f"'{name}':['Expression', 'Log2', 'lzw','{num_str}'],"


def get_umap_pl_cell_subsamp(spipe, samp, adata, from_parent=False):
    """ Get a subsample of cells (matrix rows) for umap plotting

    If subsampling is set and number of cells is greater, subsample

    Return adata, possibly with subset of rows (i.e. cells)
    """
    if from_parent and spipe.have_parent():
        adata = get_umap_pl_par_cell_ss(spipe, samp, adata)
        spipe.report_run_story2(f"Subsample umap plot cells from parent; {adata.shape}")
        return adata

    bci_ss = None
    # Subsample target number
    targ_num = spipe.get_par_val('rep_umap_subsamp', as_int=True)

    # Note: adata.raw.X has counts normalized (e.g. to 10e4)
    n_cells = adata.X.shape[0]

    if (targ_num > 0) and (n_cells > targ_num):
        # Min cells per cluster for subsampling (i.e. keep at least this many per cluster)
        min_size = spipe.get_par_val('rep_umap_ss_clus_min', as_int=True)
        spipe.report_run_story2(f"Subsampling cells to plot; Target {targ_num} with {min_size} min per cluster")
        # Get subset of indexes from list of cluster id per cell
        clust_alg = spipe.get_par_val('ana_cluster_alg', as_str=True)
        clust_list = list(adata.obs[clust_alg].values)
        cell_ss = utils.label_list_subset(clust_list, targ_num, min_keep=min_size)
        spipe.report_run_story2(f"Subsampled {len(cell_ss)} of {n_cells} cells for gex plots")
        # Convert set of array position indexes into barcode indexes for adata
        bci_ss = set()
        for i, bc in enumerate(adata.obs.index):
            if i in cell_ss:
                bci_ss.add(bc)
        adata = adata[adata.obs.index.isin(bci_ss),:]
    else:
        spipe.report_run_story2(f"No cell subsampling for gex plots; All {n_cells}")

    # Save updated UMAP plot subset info 
    if not spipe.is_focal_crispr():
        update_umap_file_cell_subsamp(spipe, samp, bci_ss)

    return adata


def get_umap_pl_par_cell_ss(spipe, samp, adata):
    """
    """
    par_dir = spipe.get_parent_info(key='path')
    umap_df = spipe.read_csv('SFR_CLUST_UMAP', samp, top_dir=par_dir)

    # Barcode index subset
    bci_ss = set(umap_df[umap_df['in_plot_ss']].index)
    adata = adata[adata.obs.index.isin(bci_ss),:]
    return adata


def update_umap_file_cell_subsamp(spipe, samp, bci_ss, top_dir=None):
    """ Update UMAP file to reflect cell subsample visibility

    """
    umap_df = spipe.read_csv('SFR_CLUST_UMAP', samp, top_dir=top_dir)
    # Cell subsample = set of indexes; If no set, assume all are in
    if bci_ss:
        umap_df['in_plot_ss'] = umap_df.index.isin(bci_ss)
    else:
        umap_df['in_plot_ss'] = True

    spipe.write_df(umap_df, 'SFR_CLUST_UMAP', samp=samp)


def umap_plot_pt_size(spipe, n):
    """Get data-dependant plotting point size for umap plots
    """
    if not isinstance(n, int):
        n = len(n)
    if n < 5000:
        outline_size = 0.5
        pt_size = 12000 / n
    else:
        outline_size = 0.1
        pt_size = 120000 / n
    return (pt_size, outline_size)


def plot_umap_static(spipe, samp, adata, ana_info, verb=True, targeted=False):
    """ Plot UMAP clusters

    return json object for plotly
    """
    if spipe.is_focal_crispr():
        print("UMAP static not yet for focal / crispr")
        return

    # Collect info to create plots; new dataframe mixing UMAP and cell values
    umap_df = pd.DataFrame(adata.obsm['X_umap'], index=adata.obs.index, columns=['x', 'y'])
    clust_alg = ana_info['cluster_alg']

    # Extra key(word) if targeted
    xkey = 'targeted_' if targeted else ''

    # Per plot value columns
    plot_cols = [clust_alg, 'sample', f"{xkey}gene_count", f"{xkey}mread_count"]
    # Per plot flags for categorical and filename key lists
    cats = [True, True, False, False]
    keys = ['CLUS', 'SAMP', 'GENES', 'READS']
    # Multiple species?
    if spipe.num_genomes() > 1:
        plot_cols.append('species')
        cats.append(True)
        keys.append('SPEC')

    umap_df[plot_cols] = adata.obs[plot_cols]
    # In case clusters should shift to 1-base
    umap_df[clust_alg] = get_cell_cluster_names(spipe, samp, adata, ana_info, unique=False, as_str=True)

    # ============ static png ==========
    # Static cluster plot collection; Only if saving static figs
    if spipe.get_par_val('rep_save_figs', as_bool=True):
        # Make full filename keys from parts
        keys = [f"SFR_FIG_UMAP_{k}" for k in keys]
        spipe.report_run_story2(f"Generating {len(plot_cols)} umap cluster plot figures")
        # For each plot
        for i, col in enumerate(plot_cols):
            # If single sample, don't make fig
            if (col == 'sample') and (len(umap_df[col].unique()) == 1):
                continue
            spipe.report_run_story2(f"Generating and saving umap cluster plot {col}")
            plot_one_umap_static(spipe, samp, keys[i], umap_df, col, cat=cats[i])


def plot_one_umap_static(spipe, samp, fkey, umap_df, val_col, cat=True, log10=True):
    """ Plot one UMAP scatter plot

    fkey = filename key
    umap_df = data, with 'x' 'y' and 'val_col'
    cat = flag to treat values as catagorical
    log10 = flag to transform (non cat) values

    Returns nothing; Saves fig to file
    """
    # Size params depend on number of cells (points)
    pt_size, outline_size = umap_plot_pt_size(spipe, len(umap_df))
    title = val_col.capitalize()

    # Category processing
    if cat:
        fig = plt.figure(figsize=(5, 5))
        # Unique names
        u_names = sorted(umap_df[val_col].unique())
        # Expand legend if too many
        lgd_cols = math.ceil(len(u_names) / 15)
        colors = sns.color_palette(n_colors=len(u_names))
        for i, val_name in enumerate(u_names):
            val_df = umap_df[umap_df[val_col] == val_name]
            plt.scatter(val_df['x'], val_df['y'], s=pt_size,
                color=colors[i], label=val_name, linewidths=outline_size, edgecolors='white')
    else:
        # Make wider for colorbar
        fig = plt.figure(figsize=(6.3, 5))
        if log10:
            colors = np.log10(umap_df[val_col])
            title += " (log10)"
        else:
            colors = umap_df[val_col]
        s = plt.scatter(umap_df['x'], umap_df['y'], s=pt_size, c=colors,
                        cmap=plt.cm.Reds, linewidths=outline_size, edgecolors='white')
        cb = fig.colorbar(s)

    # gca = get current axis
    ax = plt.gca()
    ax.set(xticklabels=[], yticklabels=[])
    plt.xlabel('UMAP 1')
    plt.ylabel('UMAP 2')
    plt.title(title)

    # Save figure to file
    fname = spipe.filepath(fkey, samp)
    if cat:
        lgd = ax.legend(bbox_to_anchor=[1.00, 0.5], markerscale=2, loc='center left', ncol=lgd_cols, frameon=False)
        plt.savefig(fname, bbox_extra_artists = [lgd], bbox_inches='tight', format='png', pad_inches=0.25, dpi=200)
    else:
        plt.savefig(fname, bbox_inches='tight', format='png', pad_inches=0.25, dpi=200)

    clear_plot_data()


##### --------------- number string encoding stuff ------------------------------


# ---- Specalized gex log2'd int case ----

# For string encoding via int-to-char mapping (used for log2'd gex values)
INTSTR2ALPH_DICT = {str(v):k for v,k in enumerate(list('abcdefghijklmnopqrstuvwxyz'))}
ALPH2INTSTR_DICT = {v:k for k,v in INTSTR2ALPH_DICT.items()}

def int_list_pack_str_lzw(nlis):
    """ Create compressed string from list of int as str

    nlis = List of str for ints 

    This is specialized for gex log2'd values; Separate function for speed

    Values are first run-lengh-encoded after mapping int to char via dict
    Then the rle-encoded str is further encoded via lzw compression

    Values are capped at 26 (length of ALPH2INTSTR_DICT); Above this all the same

    For example: [0,0,4,0,3,3,0,0,0,0,0,1] >--> 'a2dac3a5b' >--> lzw-encoded-str

    return string
    """
    new_lis = []
    prev = nlis[0]
    run = 1
    for v in nlis[1:]:
        if v == prev:
            run += 1
        else:
            # New value; Get dict encoding (or default)
            w = INTSTR2ALPH_DICT.get(prev, '?')
            # Add run-count if multiple row
            if run > 1:
                w += str(run)
            new_lis.append(w)
            prev = v
            run = 1
    # Last one
    w = INTSTR2ALPH_DICT.get(prev, '?')
    if run > 1:
        w += str(run)
    new_lis.append(w)

    # Final encoding
    nst = lzw_encode(''.join(new_lis))

    return nst


# ---- General number list case ----

def num_list_pack_str_rle(nlis, as_str=False, round_to=2):
    """ Create compressed string from list of general numbers (as num or str)

    nlis = List of numbers or str

    For example: [0,0,4,0,30,30,0,0,0,0,0,1]  >-->  '0x2,4,0,30x2,0x5,1'

    return string
    """
    # Need list of str; Possibly round and cast
    if not as_str:
        if round_to >= 0:
            nlis = [str(round(x, round_to)) for x in nlis]
        else:
            nlis = [str(x) for x in nlis]

    # vsep and isep are separators for value-counts and items, respectively
    nst = run_len_encode(nlis, trim_zero=True, vsep='x', isep=',', v2c_dict=None)
    return nst


def run_len_encode(slis, trim_zero=True, vsep='x', isep=',', v2c_dict=None, v2c_def='?'):
    """ Generate run length encoded string from list of str

    slis = List of str values
    trim_zero = Flag to trim trailing zeros from (str) numbers
    vsep = Value count separator; i.e. 'x' in '2.3x4' (four instances of 2.3)
    isep = Item separator to put together output
    v2c_dict = Dict to map values to char
    v2c_def = Def char when val not found in dic

    Return string
    """
    # If not separators, make sure it's empty str
    vsep = '' if not vsep else vsep
    isep = '' if not isep else isep

    new_lis = []
    prev = slis[0]
    run = 1
    for v in slis[1:]:
        if v == prev:
            # Same value so just increment count
            run += 1
        else:
            # New value. Get run-len-encoded of prev val (str) found run times
            w = rle_encode_one_val(prev, run, trim_zero=trim_zero, vsep=vsep, v2c_dict=v2c_dict, v2c_def=v2c_def)
            new_lis.append(w)
            prev = v
            run = 1
    # Last one
    w = rle_encode_one_val(prev, run, trim_zero=trim_zero, vsep=vsep, v2c_dict=v2c_dict, v2c_def=v2c_def)
    new_lis.append(w)

    return isep.join(new_lis)


def rle_encode_one_val(w, run, trim_zero=False, vsep='x', v2c_dict=None, v2c_def='?'):
    """ Get run length encoding string for one value and run count
    """
    if trim_zero:
        w = num_trim_zero_str(w)
    if v2c_dict:
        try:
            w = v2c_dict[w]
        except:
            w = v2c_def
    if run > 1:
        w += vsep + str(run)
    return w


# Regex to strip trailing zeros after decimal; For example
#   2.30 >--> 2.3
#   0.0 >--> 0
#   100 >--> 100
#   from https://stackoverflow.com/questions/44111169/remove-trailing-zeros-after-the-decimal-point-in-python
TRIM_TRAILZERO = re.compile(r'(?:(\.)|(\.\d*?[1-9]\d*?))0+(?=\b|[^0-9])')

def num_trim_zero_str(val):
    """Trim trailing zeros from number as STRING

    Return string
    """
    return TRIM_TRAILZERO.sub(r'\2',val)


def lzw_encode(s):
    """ This function compresses a string using the lzw algorithm

    Return string
    """
    dict_encode = {}
    data = list(s)
    out = []
    phrase = data[0]
    code = 256

    for i in range(1, len(data)):
        currChar = data[i]
        try:
            dict_encode['_' + phrase + currChar]
        except:
            if len(phrase) > 1:
                out.append(dict_encode['_' + phrase])
            else:
                out.append(ord(phrase[0]))
            dict_encode['_' + phrase + currChar] = code
            code += 1
            phrase = currChar
        else:
            phrase += currChar
    if len(phrase) > 1:
        out.append(dict_encode['_' + phrase])
    else:
        out.append(ord(phrase[0]))

    for i in range(0, len(out)):
        out[i] = chr(out[i])
    return ''.join(out)


def clean_up(spipe, final=False):
    """Clean up report stuff for given sample
    """
    # Clean up any open figure
    plt.close('all')

    if spipe.get_par_val('clean_per_step', as_bool=True) or final:
        # Temp files to remove
        f_lis = []
        f_lis.append(spipe.filepath('TMP_DIFF_TAB_HTML', None))
        utils.check_and_rm_file(f_lis)
