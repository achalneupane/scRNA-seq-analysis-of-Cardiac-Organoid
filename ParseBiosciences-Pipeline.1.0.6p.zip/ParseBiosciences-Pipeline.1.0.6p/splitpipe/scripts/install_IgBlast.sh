#!/usr/bin/env bash
#   Installs IgBlast for use with TCR package for split-pipe pipeline
#
#   Copyright (c) 2023 Parse Biosciences
#
#   See company page for background information, usage instructions and license.
#   https://www.parsebiosciences.com/
#

# set -o errexit
set -o nounset


VERSION="Version 0.2; RTK 2023-03-13"

# For version, save program name from first var, first pass
PROGNAME=$0
version() { echo "$PROGNAME $VERSION"; }

# Log file name; Full path below
PROC_LOG_NAME="install_IgBlast.log"


# Target url files
FTP_URL_LATEST="ftp://ftp.ncbi.nih.gov/blast/executables/igblast/release/LATEST/"
FTP_URL_STABLE="ftp://ftp.ncbi.nih.gov/blast/executables/igblast/release/1.20.0/"
IDX_FILE="index.html"


# Output top level
igb_top="IgBlast"

SRC_DIR=$(cd "$(dirname "$0")/.."; pwd)


main ()
{
    if [[ $# -lt 1 ]]; then
        echo "Usage: <path_above_IgBlast> [<latest>]"
        echo " "
        echo "If second arg, install from 'LATEST' ftp path"
        exit 1
    fi

    # Target source URL and version indication
    if [[ $# -gt 1 ]]; then
        FTP_URL="$FTP_URL_LATEST"
    else
        FTP_URL="$FTP_URL_STABLE"
    fi
    TARG_VERSION=$(echo $FTP_URL | tr "/" " " | awk '{print $NF}')
    
    top_dir=$1
    if [[ ! -d $top_dir ]]; then 
        echo "Bad top level dir given: $top_dir"
        exit 1
    fi
    # Get full path for top_dir (in case given relative)
    top_dir=$(cd "$top_dir"; pwd)

    # Save processing outputs to log file
    PROC_LOG="${top_dir}/${PROC_LOG_NAME}"
    [[ -e $PROC_LOG ]] && rm $PROC_LOG
    {
        echo "Install for IgBlast"
        date
        echo "-----------------"
        echo " "                    
    } >> $PROC_LOG

    # Save starting location and jump to top dir
    start_top=$(pwd)
    cd "$top_dir"

    echo "# Saving details to: $PROC_LOG"
    echo "# Will install $igb_top under $top_dir" | tee -a $PROC_LOG
    echo "# Target version $TARG_VERSION" | tee -a $PROC_LOG

    n_start_index=$(find . -name "index.html" | wc | awk '{print $1}')
    echo "# N start index $n_start_index" | tee -a $PROC_LOG

    ####  Install igBLAST package
    # Figure out lastest version download command
    # First get index to find latest tar version name from that
    echo "# Getting index for $FTP_URL" | tee -a $PROC_LOG
    call="wget $FTP_URL"
    {
        echo "$call"
        eval "$call"
        echo "-----------------"
        echo " "
    } &>> $PROC_LOG

    if [[ ! -f $IDX_FILE ]]; then
        echo "Failed to get $IDX_FILE from $FTP_URL" | tee -a $PROC_LOG
        exit 1
    fi

    # Get target ftp and filename from html index
    ftp_tar_file=$(grep x64-linux.tar $IDX_FILE | grep -v md5 | sed 's/[<>=]/ /g' | awk '{print $(NF-4)}' | sed 's/"//g')
    tar_file=$(grep x64-linux.tar $IDX_FILE | grep -v md5 | sed 's/[<>=]/ /g' | awk '{print $(NF-3)}')
    echo "# Getting $ftp_tar_file" | tee -a $PROC_LOG
    call="wget $ftp_tar_file"
    {
        echo "$call"
        eval "$call"
        echo "-----------------"
        echo " "
    } &>> $PROC_LOG

    if [[ -f $tar_file ]]; then
        echo "# Got $tar_file from $FTP_URL" | tee -a $PROC_LOG
    else
        echo "Failed to get $tar_file from $FTP_URL" | tee -a $PROC_LOG
        exit 1
    fi

    # Remove 'index.html' if this is new
    if [[ -f $IDX_FILE  ]] && [[ $n_start_index -eq 0 ]]; then
        rm $IDX_FILE
    fi

    # Untar then get dir name
    echo "# Extracting $tar_file" | tee -a $PROC_LOG
    call="tar -xf $tar_file"
    {
        echo "$call"
        eval "$call"
        echo "-----------------"
        echo " "
    } &>> $PROC_LOG

    raw_igb_top=$(find . -maxdepth 1 -type d -name "*igblast*")
    if [[ -d $raw_igb_top ]]; then
        echo "# Extracted $raw_igb_top" | tee -a $PROC_LOG
    else
        echo "Problem extracting from $tar_file" | tee -a $PROC_LOG
        exit 1
    fi

    # Done with tar
    rm "$tar_file"

    echo "# Moving raw IgBlast $raw_igb_top >--> $igb_top" | tee -a $PROC_LOG
    mv "$raw_igb_top" "$igb_top"

    # Jump into top dir, make dir for fasta files and retrieve
    cd $igb_top
    new_igb_path=$(pwd)

    # Make sure blast works
    call=" bin/makeblastdb -version"
    run_blast=$( $call )
    exit_code=$?
    if [[ $exit_code -gt 0 ]]; then
        echo "Problem with call: '${call}'" | tee -a $PROC_LOG
        echo "Exit code $exit_code" | tee -a $PROC_LOG
        exit $exit_code
    fi

    ####  Install data files
    # Download Files
    mkdir IMGT_TR
    cd IMGT_TR
    echo "# Getting fasta data files" | tee -a $PROC_LOG
    {
        wget http://www.imgt.org/download/V-QUEST/IMGT_V-QUEST_reference_directory/Homo_sapiens/TR/TRAV.fasta
        wget http://www.imgt.org/download/V-QUEST/IMGT_V-QUEST_reference_directory/Homo_sapiens/TR/TRAJ.fasta
        wget http://www.imgt.org/download/V-QUEST/IMGT_V-QUEST_reference_directory/Homo_sapiens/TR/TRBV.fasta
        wget http://www.imgt.org/download/V-QUEST/IMGT_V-QUEST_reference_directory/Homo_sapiens/TR/TRBD.fasta
        wget http://www.imgt.org/download/V-QUEST/IMGT_V-QUEST_reference_directory/Homo_sapiens/TR/TRBJ.fasta
        wget https://www.imgt.org/download/GENE-DB/IMGTGENEDB-ReferenceSequences.fasta-nt-WithGaps-F+ORF+inframeP
        echo "-----------------"
    } &>> $PROC_LOG

    # For now only get alpha and beta chains.
    # Note that using alpha and delta chains together will cause an error because the IGMT TRDV.fasta file
    # has TRAV sequences.
    # wget http://www.imgt.org/download/V-QUEST/IMGT_V-QUEST_reference_directory/Homo_sapiens/TR/TRDV.fasta
    # wget http://www.imgt.org/download/V-QUEST/IMGT_V-QUEST_reference_directory/Homo_sapiens/TR/TRDD.fasta
    # wget http://www.imgt.org/download/V-QUEST/IMGT_V-QUEST_reference_directory/Homo_sapiens/TR/TRDJ.fasta
    # wget http://www.imgt.org/download/V-QUEST/IMGT_V-QUEST_reference_directory/Homo_sapiens/TR/TRGV.fasta
    # wget http://www.imgt.org/download/V-QUEST/IMGT_V-QUEST_reference_directory/Homo_sapiens/TR/TRGJ.fasta

    echo "# Processing fasta files" | tee -a $PROC_LOG

    #Process the fasta file to get C genes
    awk -F'>' 'NF>1{f=($2 ~ /.*TR[AB]C.*Homo sapien.*/)} f' IMGTGENEDB-ReferenceSequences.fasta-nt-WithGaps-F+ORF+inframeP > human_C_sequences.fasta
    awk -F"|" '/TR/ {id = $2;if (pid == id) {} else if (!pid){print ">"id} else {print ">"id};pid=id} /^[acgtn.]/ {print}' human_C_sequences.fasta > human_C.fasta

    # Combine other segments
    cat ./*V.fasta > human_V.fasta
    cat ./*D.fasta > human_D.fasta
    cat ./*J.fasta > human_J.fasta

    # Convert IMGT files
    cd ../
    mkdir tr_fasta
    bin/edit_imgt_file.pl IMGT_TR/human_V.fasta > tr_fasta/human_V
    bin/edit_imgt_file.pl IMGT_TR/human_D.fasta > tr_fasta/human_D
    bin/edit_imgt_file.pl IMGT_TR/human_J.fasta > tr_fasta/human_J
    bin/edit_imgt_file.pl IMGT_TR/human_C.fasta > tr_fasta/human_C

    echo "# Building BLAST database" | tee -a $PROC_LOG
    # Make the database
    mkdir tr_database
    {
        bin/makeblastdb -parse_seqids -dbtype nucl -in tr_fasta/human_V -out tr_database/human_V
        bin/makeblastdb -parse_seqids -dbtype nucl -in tr_fasta/human_D -out tr_database/human_D
        bin/makeblastdb -parse_seqids -dbtype nucl -in tr_fasta/human_J -out tr_database/human_J
        bin/makeblastdb -parse_seqids -dbtype nucl -in tr_fasta/human_C -out tr_database/human_C    
    } &>> $PROC_LOG


    # Jump back to starting dir; 
    cd "$start_top"

    echo "# IgBlast dir: $new_igb_path" | tee -a $PROC_LOG
    echo "# IgBlast log: $PROC_LOG"
    echo "# All done. Finished successfully" | tee -a $PROC_LOG

}


# Call main with all command line args
main "$@"

