#!/usr/bin/env bash
#   Runs mkref step for focal / CRISPR with --gfasta input (e.g. gRNA seqs)
#
#   Copyright (c) 2023 Parse Biosciences
#
#   See company page for background information, usage instructions and license.
#   https://www.parsebiosciences.com/
#

# set -o errexit
set -o nounset


VERSION="Version 0.1; RTK 2023-04-11"

# For version, save program name from first var, first pass
PROGNAME=$0
version() { echo "$PROGNAME $VERSION"; }


main ()
{
    if [[ $# -lt 3 ]]; then
        echo " "
        version
        echo " "
        echo "Usage: <genome_name> <fasta> <output_dir> <pars>"
        echo " "
        echo "  <genome_name>   Genome name for split-pipe mkref --gfasta use"
        echo "  <fasta>         Fasta file for split-pipe mkref --gfasta use"
        echo "  <output_dir>    Path for split-pipe mkref --output_dir"
        echo "  <pars>          Path for split-pipe mkref --parfile"
        echo " "
        exit 1
    fi

    genome_name=$1
    fasta=$2
    output_dir=$3
    parfile=$4
    
    call="split-pipe --mode mkref \
        --parfile $parfile \
        --gfasta $genome_name $fasta \
        --output_dir $output_dir"
    
    echo " "
    echo "Call: ${call}"

    run_mkref=$( $call )
    exit_code=$?
    if [[ $exit_code -gt 0 ]]; then
        echo "Problem with call: '${call}'" 
        echo "Exit code $exit_code" 
        exit $exit_code
    fi
    
    echo "Allegedly coooo"

}


# Call main with all command line args
main "$@"


