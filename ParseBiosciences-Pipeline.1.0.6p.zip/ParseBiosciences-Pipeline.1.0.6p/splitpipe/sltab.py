#
#   Copyright (c) 2023 Parse Biosciences
#
#   See company page for background information, usage instructions and license.
#   https://www.parsebiosciences.com/
#
# Sample loading table functions

import numpy as np
import pandas as pd


LOCAL_IMPORT=0

if LOCAL_IMPORT:
    import plates
    import utils
else:
    from splitpipe import plates
    from splitpipe import utils


### ------------------------------ SampleLoadingTable --------------------------------
# Keywords to parse 'sample' sheet
NUM_SAMP_KEY = 'number of samples:'

SAMP_NUM_KEY = 'sample'
SAMP_NAME_KEY = 'sample name'
SAMP_PERC_KEY = 'percent'
SAMP_NWELL_KEY = '# wells'
SAMP_CONC1_KEY = 'stock concentration'
SAMP_CONC2_KEY = "req'd sample conc"

# Defines for 'plate' sheet
ROW_LABS = list('ABCDEFGH')
COL_LABS = [str(i+1) for i in range(12)]
PLATE_N_ROWS = len(ROW_LABS)
PLATE_N_COLS = len(COL_LABS)

# Mapping plate coords to well string; e.g. (1,3) >--> B4
well_coords_to_str = {}
for i,row in enumerate(ROW_LABS):
    for col in range(PLATE_N_COLS):
        well = f"{row}{col+1}"
        coords = (i,col)
        well_coords_to_str[coords] = well


def parse_sampleloadingtable(fname, verb=True, keep_dfs=False):
    """ Parse sample loading table

    Return dict with source and per sample info
    """
    sltab_info = {}
    # Dataframes for sheets
    sltab_dict = get_sltab_excel_dfs(fname)
    if not sltab_dict:
        return None

    # List of samples and df with wells
    samp_list = parse_sltab_sample_df(sltab_dict['sample'])
    if not samp_list:
        return None
    # Plate well info, specification strings
    wells_df = parse_sltab_plate_df(sltab_dict['plate'])
    if wells_df is None:
        return None

    # Set well specification string for each sample
    wspec_list = plates.plate_samp_well_specs(wells_df)
    for s_dict, well_str in zip(samp_list, wspec_list):
        s_dict['wells'] = well_str

    # Save info
    sltab_info['filename'] = fname
    sltab_info['samples'] = samp_list
    sltab_info['num_samples'] = len(samp_list)
    sltab_info['num_wells'] = plates.num_snum_wells(wells_df, -1)
    if keep_dfs:
        sltab_info['wells_df'] = wells_df
        sltab_info['plate_df'] = sltab_dict['plate']
        sltab_info['sample_df'] = sltab_dict['sample']

    if verb:
        print("# --------------------------------------------")
        print(f"# Samples from SampleLoadingTable: {fname}")
        for s_dict in samp_list:
            print("# ", s_dict['number'], s_dict['name'], s_dict['wells'])
        print("# --------------------------------------------")
        print(f"# Table has {len(samp_list)} samples in {sltab_info['num_wells']} wells:")
        plate = utils.report_df_str(wells_df, pref='#  ', index_name='Wells', row_num=False)
        print(plate)
        print("# --------------------------------------------")

    return sltab_info


def get_sltab_excel_dfs(fname):
    """ Attempt to parse SampleLoadingTable excel to dataframes per sheet

    Return dict of dataframes 'sample' and 'plate'
    """
    sheets = {}
    try:
        raw_sheets = pd.read_excel(fname, sheet_name=None)
    except Exception as e:
        print(f"Failed to parse excel: {e}")
        return None

    # Find sample table and plate configuration sheets
    samp_df = plate_df = None
    for sname in raw_sheets.keys():
        if sname.lower().startswith('sample'):
            samp_df = raw_sheets[sname]
        if sname.lower().startswith('plate'):
            plate_df = raw_sheets[sname]
    if (samp_df is None) or (plate_df is None):
        print(f"Could not find sample and plate sheets")
        print("Sheet names:", raw_sheets.keys())
        return None

    sheets['sample'] = samp_df
    sheets['plate'] = plate_df
    return sheets


def parse_sltab_sample_df(df):
    """ Parse 'Sample Table' (excel) sheet dataframe

    Return list of dicts with sample data
    """
    col_keys = {}
    num_samp = 0
    row = 0
    # Get number of samples and data column positions
    while row < len(df):
        # Listed number of samples
        if str(df.iloc[row, 0]).lower().startswith(NUM_SAMP_KEY):
            for col in range(1, df.iloc[row].count()):
                g, v = utils.str_to_num(df.iloc[row,col])
                if g:
                    num_samp = v
                    break
        # Data row with column headers starts with sample number
        elif (num_samp > 0) and str(df.iloc[row, 0]).lower().startswith(SAMP_NUM_KEY):
            for j in range(df.iloc[row].count()):
                if str(df.iloc[row, j]).lower().startswith(SAMP_NAME_KEY):
                    col_keys['name'] = j
                elif str(df.iloc[row, j]).lower().startswith(SAMP_NUM_KEY):
                    col_keys['number'] = j
                elif str(df.iloc[row, j]).lower().startswith(SAMP_PERC_KEY):
                    col_keys['percent'] = j
                elif str(df.iloc[row, j]).lower().startswith(SAMP_NWELL_KEY):
                    col_keys['num_wells'] = j
                elif str(df.iloc[row, j]).lower().startswith(SAMP_CONC1_KEY):
                    col_keys['conc1'] = j
                elif str(df.iloc[row, j]).lower().startswith(SAMP_CONC2_KEY):
                    col_keys['conc2'] = j
            break
        row += 1
    # Check collected data so far ok
    if (num_samp < 1) or (len(col_keys) < 6):
        print(f"Could not find sample info row; Row {row}, Keys {col_keys}")
        return None

    # Should be positioned at data col label row; Advance to start of data
    row += 1

    # Collect row data for samples, starting next line
    samp_data = []
    n = 0
    while (n < num_samp) and (row < len(df)):
        sdat = {
            'name': df.iloc[row, col_keys['name']],
            'number': df.iloc[row, col_keys['number']],
            'percent': df.iloc[row, col_keys['percent']],
            'num_wells': df.iloc[row, col_keys['num_wells']],
            'conc1': df.iloc[row, col_keys['conc1']],
            'conc2': df.iloc[row, col_keys['conc2']],
        }
        samp_data.append(sdat)
        n += 1
        row += 1

    # Check correct sample count
    if n < num_samp:
        print(f"Loaded {n} sample data rows but expecting {num_samp}")
        return None

    return samp_data


def parse_sltab_plate_df(df):
    """ Parse 'Plate Configuration' grid from excel sheet dataframe

    Return plate-form dataframe
    """
    # Search for first cell with only 'A' as starting corner of plate
    row = col = -1
    for i in range(len(df)):
        if 'A' in list(df.iloc[i]):
            row = i
            for j in range(df.iloc[row].count()):
                if str(df.iloc[i, j]) == 'A':
                    col = j
                    break
    # Check we got start corner
    if (row < 0) or (col < 0):
        print(f"Could not find plate 'A' marker; Row {row}, col {col}")
        return None

    # New dataframe from table
    # No checking excel; Just grab rows x cols first
    wells = df.iloc[row:row+PLATE_N_ROWS, col+1:col+1+PLATE_N_COLS]
    wells.index = ROW_LABS
    wells.columns = [str(i+1) for i in range(PLATE_N_COLS)]
    # Remove non-real wells; i.e. drop rows with all missing numbers
    ok_rows = []
    for row in wells.index:
        if not wells.loc[row].isnull().all():
            ok_rows.append(row)

    # Legit rows, missing = 0 and all as int
    wells = wells.loc[ok_rows, :].replace(np.nan, 0).astype(int)
    return wells
