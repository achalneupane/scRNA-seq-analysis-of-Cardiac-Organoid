#
#   Copyright (c) 2023 Parse Biosciences
#
#   See company page for background information, usage instructions and license.
#   https://www.parsebiosciences.com/
#


LOCAL_IMPORT=0

if LOCAL_IMPORT:
    import kits
    import plates
    import spclass
    import spoutdir as spout
    import utils
else:
    from splitpipe import kits
    from splitpipe import plates
    from splitpipe import spclass
    from splitpipe import spoutdir as spout
    from splitpipe import utils


# ---------------------------------------------------------------------------
class SpSamp():
    """ Class for 'sample' info

        Single mode = data from single analysis, single plate of wells
        Combine mode = multiple analysis, (dict of) well info for each sublibrary

        Simple = well definition
        Meta = other sample definition
    """
    def __init__(self, name, wells='', plate_nwells=0, sublibs=[], samples=[]):
        """ Initialize structure

        name = Name of target
        wells = Well specification (string) for well subset (e.g. A2-A6,B5:C10)
        plate_nwells = Number of wells for R1 plate
        sublibs = Collection of sublibrary structs (combine mode only)
        samples = Collection of sample str or structs (i.e. meta parts if meta sample)

        Need either wells or samples (single mode) or sublibs (combine mode)
        """
        self.name = name
        self.well_str = self.part_str = ''
        self._sublibs = sublibs
        self._meta_parts = samples
        self._am_meta = False
        self._n_plate = plate_nwells

        # Collection of info for sublib structs; samples, well strings and index lists
        # Lists so we can handle collections same if single or combine mode
        # All lists same length as sublibs
        self._all_sub_samples = []
        self._all_wells = []
        self._all_wind_list = []

        # Combine mode. If sublibraries, collect well / sample info for each sublib
        if self._sublibs:
            # If dict, get list
            if isinstance(self._sublibs, dict):
                self._sublibs = list(self._sublibs.values())

            # Collect sample for each sublib, along with well info
            well_set = set()
            part_set = set()
            for slib in self._sublibs:
                assert isinstance(slib, spout.SpOut), f"Expected SpOut got {type(slib)}"
                # Get well and sub_well, or nothing / empty
                ssamp = slib.get_samples(one=name)
                if ssamp:
                    ss_parts = ssamp.get_meta_part_str()
                    ss_wells = ssamp.get_wells()
                    ss_wind_list = ssamp.get_wind_list()
                    # Number of wells for full plate; Set or check
                    np = ssamp.get_num_wells(plate=True) 
                    if not self._n_plate:
                        self._n_plate = np
                    else:
                        if self._n_plate != np:
                            story = f"Plate wells {np} for sublib {slib.get_name()} != {self._n_plate}"
                            raise ValueError(story)
                else:
                    ss_parts = ss_wells = ''
                    ss_wind_list = []
                self._all_sub_samples.append(ssamp)
                self._all_wells.append(ss_wells)
                self._all_wind_list.append(ss_wind_list)

                well_set.add(ss_wells)
                # Separate parts from string (e.g. 'A,B,C' >--> 'A' 'B' 'C')
                part_set.update(ss_parts.split(','))

            # If any parts collected, this is meta
            real_parts = [p for p in part_set if p]
            if real_parts:
                self._am_meta = True
                self.part_str = ','.join(real_parts)
            # Set well spec string; If any and all the same, use that
            if well_set:
                if len(well_set) == 1:
                    self.well_str = f"{list(well_set)[0]}... combined common"
                else:
                    self.well_str = "combined; mixed well sets"

        # Single mode. Just one sublib / plate
        else:
            # Meta sample = combine parts
            if self._meta_parts:
                compatible_meta_samples(self._meta_parts, fatal=True)

                self.set_meta_part_samples(self._meta_parts)
                # Collect names, well str and indexes from parts
                name_list = []
                well_list = []
                wind_list = []
                for samp in self._meta_parts:
                    assert isinstance(samp, SpSamp), f"Expected SpSamp got {type(samp)}"
                    name_list.append(samp.get_name())
                    well_list.append(samp.get_wells())
                    wind_list.append(samp.get_wind_list())
                self.part_str = ','.join(name_list)
                # Combine well indexes into single unique list
                ind_set = set()
                for wlist in wind_list:
                    for ind in wlist:
                        ind_set.add(ind)
                wind_list = list(ind_set)
                wells = None
            else:
                ok, wind_list, story = plates.parse_96wells(wells)
                if not ok:
                    raise ValueError(story)
            self.set_single_samp_info(wells, wind_list)


    def __del__(self):
        pass


    def __repr__(self):
        ostring = "SpSamp (sample definition)\n"
        ostring += f"Name:    {self.name}\n"
        ostring += f"Wells:   {self.get_wells()} ({self.get_num_wells()})\n"
        type_story = self.get_type_str()
        ostring += f"Type:    {type_story}\n"
        if self.is_meta():
            ostring += f"Samples: {self.get_meta_part_str()}\n"
        return ostring


    def get_name(self):
        return self.name


    def get_def_str(self):
        if self.is_meta():
            answer = self.get_meta_part_str()
        else:
            answer = self.get_wells()
        return answer


    def get_type_str(self):
        comb = self.get_combine_type_str()
        meta = self.get_meta_type_str()
        story = f"{comb}, {meta}"
        return story


    def get_combine_type_str(self):
        n_subs = self.num_sublibs()
        story = f"combined {n_subs} sublibs" if (n_subs > 1) else "single"
        return story


    def get_meta_type_str(self):
        n_samps = self.num_meta_parts()
        story = f"meta {n_samps} samples" if self.is_meta() else "simple"
        return story


    def get_wells(self, which=0):
        """ Get wells (string) specification
        """
        which = max(0, which)
        return self._all_wells[which]


    def get_wind_list(self, which=0):
        """ Get (set of) well indexes
        """
        which = max(0, which)
        return self._all_wind_list[which]


    def get_num_wells(self, which=0, all_sublibs=False, plate=False):
        """ Count of wells

        all_sublibs =   Flag to tally across all sublibs
        plate =         Flag to return number of wells for R1 plate

        Return int
        """
        n = 0
        if plate:
            n = self._n_plate
        elif all_sublibs:
            for i in range(self.num_sublibs()):
                n += len(self.get_wind_list(which=i))
        else:
            n = len(self.get_wind_list(which=which))
        return n


    def get_sublib_sample(self, which=0):
        """ Get (set of) well indexes
        """
        which = max(0, which)
        return self._all_sub_samples[which]


    def set_meta_part_samples(self, samples):
        """ Set meta part samples
        """
        self._meta_parts = samples
        self._am_meta = True


    def set_single_samp_info(self, wells, wind_list):
        """ Set well info for single (non-combine) sample
        """
        # If wells not given, get minimized well spec string from list of wells
        if not wells:
            wells = plates.well_index_to_str(wind_list, minimize=True)
        self.well_str = wells
        # Save as lists even for single mode
        self._all_wells = [wells]
        self._all_wind_list = [wind_list]
        self._all_sub_samples = [None]


    def get_meta_part_str(self):
        return self.part_str


    def is_allwell(self, meta=True):
        """ True if all-well sample

        meta = flag to allow meta sample

        return Boolean
        """
        if self.is_meta() and (not meta):
            return False

        # All well has full count of wells
        n_plate_wells = self.get_num_wells(plate=True)
        n_samp_wells = self.get_num_wells()
        return bool(n_samp_wells == n_plate_wells)


    def is_allsample(self, samp_list):
        """ True if all-sample sample

        samp_list = list or dict with sample names or SplitPipe obj that can yield this

        all-sample is made of all non-meta samples except all-well

        return Boolean
        """
        # Get list of all simple, non-all-well sample names
        if isinstance(samp_list, list):
            pass
        elif isinstance(samp_list, dict):
            samp_list = samp_list.keys()
        elif isinstance(samp_list, spclass.SplitPipe):
            samp_list = samp_list.get_samples(as_name=True, meta=False, allwell=False)
        else:
            story = f"is_allsample given unknown 'kit' type {type(samp_list)}"
            raise Exception(story)

        # Lists of sample names for this sample and given list
        this_samp_set = set(self.get_meta_parts(as_name=True))
        simp_samp_set = set(samp_list)

        # All sample if collection of parts is the same as all simple (non-meta) samples
        return this_samp_set == simp_samp_set


    def get_full_wind_list(self):
        """ Get full set of wells; If sublibs, combine all positions

        Return list of well indexes
        """
        wset = set()
        for i in range(self.num_sublibs()):
            wset = wset | set(self.get_wind_list(i))
        return sorted(list(wset))


    def get_full_well_count(self):
        """ Get total number of wells (across sublibs)

        Return int
        """
        n_tot = 0
        for i in range(self.num_sublibs()):
            n_tot += self.get_num_wells(i)
        return n_tot


    def is_combined(self):
        """ If current sample combined mode or single?

        return Boolean
        """
        return bool(self.num_sublibs() > 1)


    def num_sublibs(self, min_wells=0):
        """ Get number of sublibs that have any wells

        min_wells = qualifer to count sublib or not

        Even is no sublibs for combine mode, return 1 for current single sublib

        Return int >= 1
        """
        n_slib = len(self.get_sublibs())
        if not n_slib:
            n_slib = 1
        n = 0
        for i in range(n_slib):
            if len(self.get_wind_list(i)) >= min_wells:
                n += 1
        return n


    def get_sublibs(self):
        """ List of sublibrary structs

        Return list
        """
        return self._sublibs


    def is_meta(self):
        """ If current sample is a meta sample of others

        return Boolean
        """
        return self._am_meta


    def is_simple(self):
        """ If current sample is simple (not-meta) 

        return Boolean
        """
        return not self.is_meta()


    def num_meta_parts(self, meta=True, simple=True):
        """ Get number of (meta) samples

        Return int
        """
        parts = self.get_meta_parts(meta=meta, simple=simple)
        return len(parts)


    def get_meta_parts(self, as_name=False, meta=True, simple=True, unwrap=False):
        """ List of meta sample parts

        as_name     = flag to return names rather than objects
        meta        = flag to include meta samples
        simple      = flag to include simple (non-meta) samples
        unwrap      = flag to unwrap to only get non-meta (simple) samples

        Return list
        """
        # Special case to unwrwap down to non-meta sample parts
        if unwrap:
            return unwrap_meta_parts(self, as_name=as_name)

        answer = []
        for part in self._meta_parts:
            keep = True
            # Meta or simple qualifiers
            if self.is_meta():
                if not meta:
                    keep = False
            else:
                if not simple:
                    keep = False
            if keep:
                if as_name:
                    part = part.get_name()
                answer.append(part)
        return answer


    def equals(self, other, name=True, wells=True, parts=True):
        """ Compare other sample to current one

        name    = Flag to compare name
        wells   = Flag to compare wells
        parts   = Flag to compare meta-sample parts

        Return tuple (status, story if false)
        """
        same = True
        story = []
        # Compare indicated parameters
        if name:
            if self.get_name() != other.get_name():
                same = False
                story.append(f"Names differ: {self.get_name()} vs {other.get_name()}")
        if wells:
            f_list = self.get_wind_list()
            s_list = other.get_wind_list()
            if f_list != s_list:
                same = False
                story.append(f"Well lists differ: lens {len(f_list)} vs {len(s_list)}")
        if parts:
            f_parts = self.get_meta_part_str()
            s_parts = other.get_meta_part_str()
            if f_parts != s_parts:
                same = False
                story.append(f"Part lists differ: {f_parts} vs {s_parts}")
        return same, story


    def get_sample_specs(self):
        """ Get define settings for sample (e.g. for json)

        Return dict
        """
        ndict = {}
        ndict['name'] = self.get_name()
        ndict['wells'] = self.get_wells()
        ndict['wind_list'] = ','.join([str(i) for i in self.get_wind_list()])
        ndict['num_wells'] = self.get_num_wells()
        ndict['plate_nwells'] = self.get_num_wells(plate=True)

        # Parts for meta sample
        ndict['meta'] = self.is_meta()
        if self.is_meta():
            samples = self.get_meta_parts()
            samp_list = [s.get_name() for s in samples]
            ndict['sample_num'] = len(samp_list)
            ndict['sample_list'] = samp_list

        # Sublibs for combine mode
        ndict['combined'] = self.is_combined()
        if self.is_combined():
            sublibs = self.get_sublibs()
            slib_list = []
            for i, slib in enumerate(sublibs):
                slib_dict = {
                    'sublib_name': slib.get_name(),
                    'sublib_wells': self.get_wells(which=i),
                }
                slib_list.append(slib_dict)
            ndict['sublib_num'] = len(slib_list)
            ndict['sublib_list'] = slib_list
        return ndict


    def write_def(self, ofname):
        """ Write def / specs to file

        Returns nothing
        """
        o_dict = {}
        o_dict['header'] = utils.get_header_dict(desc='Sample specification')
        o_dict['sample'] = self.get_sample_specs()
        utils.write_json(o_dict, ofname)


def unwrap_meta_parts(samp, as_name=False):
    """ Unwrap sample to basis set of non-meta (simple) parts

    Return list
    """
    # Recursively collect list of samples
    answer = []
    if samp.is_meta():
        for part in samp.get_meta_parts():
            if part.is_meta():
                answer.extend(unwrap_meta_parts(part))
            else:
                answer.append(part)
    else:
        answer.append(samp)
    # Make sure samples are unique; Maybe return just name
    answer = sorted(list(set(answer)), key=lambda s: s.get_name())
    if as_name:
        answer = [s.get_name() for s in answer]

    return answer


def compatible_meta_samples(samples, fatal=True):
    """ Check list of samples for compatability as meta sample parts

    return tuple (status, story)
    """
    ok = True
    story = ''

    # Make sure all samples are legit
    if ok:
        for i, samp in enumerate(samples):
            if type(samp) != SpSamp:
                ok = False
                story = f"Expected SpSamp got {type(samp)} for item {i+1}"
                break

    # Check if any sublibs all agree
    if ok:
        f_list = samples[0].get_sublibs()
        for i, samp in enumerate(samples[1:]):
            s_list = samp.get_sublibs()
            if s_list != f_list:
                ok = False
                story = f"(Meta)sample sublib lists differ\n"
                story += f"1 {samples[0].get_name()} list: {f_list}"
                story += f"{i+1} {samp.get_name()} list: {s_list}"
                break

    if fatal and not ok:
        raise Exception(story)

    return ok, story


def sort_samp_list_sim_met_all(samples, sort=False):
    """ Sort sample list so simple, then meta, then all(well or sample) 

    samples = dict or list of sample objs

    Return list
    """
    # Dict with names as keys
    if isinstance(samples, dict):
        s_dict = samples
    else:
        s_dict = {s.get_name():s for s in samples}

    # Names, maybe sort order
    name_list = s_dict.keys()
    if sort:
        name_list = sorted(name_list)
    # Lists of simple, meta, and all-x samples
    s_list = []
    m_list = []
    a_list = []
    for name in name_list:
        samp = s_dict[name]
        if name in ['all-well', 'all-sample']:
            a_list.append(name)
        elif samp.is_meta():
            m_list.append(name)
        else:
            s_list.append(name)

    # From names back to obj list
    answer = []
    name_list = s_list + m_list + a_list
    for name in name_list:
        answer.append(s_dict[name])

    return answer


def order_sample_list(slist, sort_name=True):
    """ Order sample list to allow meta sample processing
    
    Meta samples have to reference previously defined samples

    slist       = sample list; May be objs or list of sample def lists
    sort_name   = flag to sort by name

    Return tuple (status, sorted list, story)
    """
    # List of names and dict with either defs or sample objs
    name_list = []
    in_dict = {}
    as_def = False
    for s in slist:
        if isinstance(s, SpSamp):
            name = s.get_name()
            val = s
        elif isinstance(s, list):
            # As sample definition string <name> <def>
            name, val = s[:2]
            as_def = True
        else:
            story = f"order_sample_list: unknown list item: {type(s)}"
            raise Exception(story)

        in_dict[name] = val
        name_list.append(name)
    if sort_name:
        name_list = sorted(name_list)

    # List of outputs and set to keep track of what's been assigned
    order_list = []
    order_set = set()
    ok = True
    story = ''

    # First pass = collect non meta samples (simple well defintions)
    for name in name_list:
        val = in_dict[name]
        if as_def:
            # Well definition; Returns tuple (status, wind_list, story-if-problem)
            # If parse status is good, this is not a meta sample
            not_meta, wlist, _ = plates.parse_96wells(val)
        else:
            # val is a sample obj
            not_meta = val.is_simple()
        if not_meta:
            if as_def:
                order_list.append([name, val])
            else:
                order_list.append(val)
            order_set.add(name)

    # Second pass for meta samples
    while ok and len(order_list) < len(in_dict):
        n_add = 0
        for name in name_list:
            # Only consider not-yet-ordered samples; If already have, skip
            if name in order_set:
                continue
            val = in_dict[name]

            # Meta definition as comma,sep,samples
            if as_def:
                def_str = val
            else:
                def_str = val.get_meta_part_str()
            part_list = def_str.split(',')
            if len(part_list) < 2:
                ok = False
                story = "Problem with sample def: '{name}' '{def_str}''"
                break

            # If all meta sample parts are already found, save current
            if set(part_list).issubset(order_set):
                n_add += 1
                order_set.add(name)
                if as_def:
                    order_list.append([name, def_str])
                else:
                    order_list.append(val)

        # If no additions, we're stuck (cyclic graph, etc?)
        if not n_add:
            ok = False
            story = "Problem parsing wells / resolving meta-parts for sample def(s);"
            for name in name_list:
                if name not in order_set:
                    val = in_dict[name]
                    story += f"\nSample: '{name}' '{val}'"

    return ok, order_list, story


def clean_sample_def_name(name, ok_num_start=True):
    """ Clean given sample name chars and so not ambiguous with respect to wells

    Clean up restricted chars, etc (names are part of filepaths in output)
    If a sample is named as a well, change; e.g. 'd1' >--> 'sample_d1'

    Return name, story
    """
    well_list = plates.wells_for_96plate()
    new_name = name
    # Clean chars; "non-variable" chars go to underscore. Also allow dash
    new_name = utils.clean_vname_chars(name, to_under=True, dash_ok=True)
    if not new_name:
        new_name = 'sample'
    # Name like a well?
    if new_name.upper() in well_list:
        new_name = 'sample_' + new_name
    # Naked number? (Not clean step changes floats like '1.3' >--> '1_3'
    ok, val = utils.str_to_num(new_name)
    if ok:
        new_name = 'sample_' + new_name
    # Start with a number?
    if not ok_num_start:
        ok, val = utils.str_to_num(new_name[0])
        if ok:
            new_name = 'sample_' + new_name
    # Name change?
    story = ''
    if new_name != name:
        story = f"Cleaned sample name '{name}' >--> '{new_name}'"

    return new_name, story
